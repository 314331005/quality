package cn.com.whye.system.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import cn.com.whye.core.service.IBaseService;
import cn.com.whye.system.domain.SysMenu;
import cn.com.whye.system.domain.SysRole;
import cn.com.whye.system.domain.SysUser;

public interface ISystemService extends IBaseService {
	
	public SysUser loginUser(String loginName, String loginPass);
	
	public SysUser initPass(SysUser user);
	
	public Collection<SysMenu> getUserMenus(SysUser user);
	
	public <T> int updateStatus(Class<T> clazz, String id, int status);
	
//	public <T> int updateCodeStatus(Class<T> clazz, String type, String code, int status);
	
	public Map<String, Integer> updateCodeStatus(String[] cids, int status);
	
	public int deleteCodes(String[] cids);
	
	public SysUser updateUserAndRoles(SysUser u, String oldPass, String roleIds);
	
	public SysRole updateRoleAndMenus(SysRole r, String menuIds);
	
	public <T> T saveNextLevel(Class<T> clazz, T obj) throws Exception;
	
	public void deleteDept(String id);
	
	public <T> List<String> deleteSelfAndChilds(Class<T> clazz, String id);
	
	public void updateTreeSameLevelSeqno(Class<?> clazz, String sortedIds) throws Exception;
	
	public <T> T genSysEntryCode(Class<T> clazz, String pid, int level);
	
	public String buildDWZMenuTreeHTML(SysUser user, String contextPath);
	
	public String buildDWZMenuTreeHTML(Collection<SysMenu> menus, String contextPath);
}
