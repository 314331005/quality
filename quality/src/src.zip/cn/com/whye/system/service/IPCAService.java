package cn.com.whye.system.service;

import java.util.Map;

import cn.com.whye.core.service.IBaseService;

public interface IPCAService extends IBaseService {

	public Map<String, String> loadPCA();
	
}
