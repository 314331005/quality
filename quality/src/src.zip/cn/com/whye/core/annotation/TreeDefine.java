package cn.com.whye.core.annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 该注解应声明在实体类上，用作树形结构数据的构造
 * @author 	wq
 * @date	2014-09-17
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface TreeDefine {
	
	public String text();
	
	public String value() default "";
	
	public String url() default "";
	
	public String valid() default "";
	
}