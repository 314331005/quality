package cn.com.whye.core.annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 该注解应声明在实体类的属性上，用作树形结构数据的构造
 * @author 	wq
 * @date	2014-09-17
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Documented
public @interface TreeColumn {
	
	public String value() default "";
	
}