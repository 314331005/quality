package cn.com.whye.core.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.nutz.dao.entity.Record;
import org.nutz.dao.sql.Criteria;

import cn.com.whye.core.domain.TreeNode;
import cn.com.whye.core.query.OrderType;
import cn.com.whye.core.query.Page;
import cn.com.whye.core.utils.ProcType;


public interface IBaseService {
	
	public void call(final String procName, final Map<String, Object> inParams);
	
	public Map<String, Object> call(final String procName, 
			final Map<String, Object> inParams, final Map<String, ProcType> outParams);

	public long getNextVal(final String key, long defaultValue);
	
	public long setNextVal(final String key);
	
	public <T> T fetch(Class<T> clazz, Criteria cri);
	
	public <T> T fetch(Class<T> clazz, Criteria cri, boolean bornIfNull);
	
	public <T> T fetch(Class<T> clazz, boolean bornIfNull, Object... pks);
	
	public <T> T fetch(Class<T> clazz, String pkName, String pkValue);
	
	public Record fetch(final String tableName, Criteria cri);
	
	public <T> T fetch(Class<T> clazz, String pkValue, boolean bornIfNull);
	
	public <T> T fetch(Class<T> clazz, Map<String, String> values);
	
	public <T> boolean checkUnique(Class<T> clazz, String uniquePropName, String uniquePropValue, String pkValue);
	
	public <T> boolean checkUnique(Class<T> clazz, String uniquePropName, String uniquePropValue, String pkName, String pkValue);
	
	public <T> boolean checkUnique(Class<T> clazz, Criteria cri, String pkValue);
	
	public <T> boolean checkUnique(Class<T> clazz, Criteria cri, String pkName, String pkValue);
	
	public <T> boolean checkCodeUnique(Class<T> clazz, String type, String code, String pkValue);
	
	public <T> List<T> query(Class<T> clazz, Criteria cri);
	
//	public List<Record> query(final String tableName, Criteria cri);
	
	public <T> List<String> findIds(Class<T> clazz, String propName, Object propValue);
	
	public <T> List<String> findIds(Class<T> clazz, Map<String, String> values);
	
	public <T> List<Map<String, String>> findMapList(Class<T> clazz, 
			Map<String, String> values, Map<String, OrderType> orderMap, Collection<String> propNames);
	
	public <T> Page<T> findPage(Class<T> clazz, Page<T> page, Criteria cri);
	
	public <T> Page<T> findPage(Class<T> clazz, Page<T> page, Criteria cri, Map<String, String> values);
	
	public <T> List<T> findList(Class<T> clazz, Map<String, String> values, String orderPropName, OrderType orderType);
	
	public <T> List<T> findList(Class<T> clazz, Map<String, String> values, Map<String, OrderType> orderMap);
	
	public <T> List<T> findAll(Class<T> clazz, String orderPropName, OrderType orderType);
	
	public <T> List<T> findAll(Class<T> clazz, Map<String, OrderType> ordersMap);
	
	public <T> T findLinks(T obj, String linkPropName, String linkOrderPropName);
	
	public <T> T findBaseAndLinks(Class<T> clazz, String pkValue, String linkPropName, String linkOrderPropName);
	
	public <T> List<T> findAllAndLinks(Class<T> clazz, String orderPropName, String linkPropName, String linkOrderPropName);
	
	public <T> T update(T target);
	
	public <T> T update(T target, String... pks);
	
	public <T> T updateBaseAndLinks(T target, final String linkPropName);
	
	public <T> T updateBaseAndLinks(T target, List<String> linkPropNames);
	
	public <T> int delete(T target);
	
	public <T> int deleteAll(Class<T> clazz);
	
	public <T> int delete(Class<T> clazz, Criteria cri);
	
	public <T> int delete(Class<T> clazz, String pkValue);
	
	public <T> int delete(Class<T> clazz, String pkName, String pkValue);
	
	public <T> int delete(Class<T> clazz, String[] pkValues);
	
	public <T> int delete(Class<T> clazz, List<String> pkValues);
	
	public <T> int deleteLinks(T obj, String regexLinksPropName);
	
//	public int deleteLinks(String linkTableName, String pkName, Object pkValue);
	
	public <T> int deleteBaseAndLinks(T obj, String regexLinksPropName);
	
	public <T> int deleteBaseAndLinks(Class<T> clazz, String id, String regexLinkPropNames);
	
//	public <T> int deleteBaseAndLinks(Class<T> clazz, String linkTableName, String pkName, String pkValue);
	
	public <T> String getTreeJsonString(Class<T> clazz);
	
	public <T> String getTreeJsonString(Class<T> clazz, boolean isOpenAll);
	
	public <T> String getTreeJsonString(Class<T> clazz, Map<String, String> values);
	
	public <T> String getTreeJsonString(Class<T> clazz, Map<String, String> values, boolean isOpenAll);
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list);
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list, final String key, final String pkey);
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list);
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list, final String key, final String pkey);
	
}
