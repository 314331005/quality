package cn.com.whye.core.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Chain;
import org.nutz.dao.Cnd;
import org.nutz.dao.ConnCallback;
import org.nutz.dao.Dao;
import org.nutz.dao.entity.Record;
import org.nutz.dao.entity.annotation.ManyMany;
import org.nutz.dao.sql.Criteria;
import org.nutz.dao.sql.OrderBy;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.ContinueLoop;
import org.nutz.lang.Each;
import org.nutz.lang.ExitLoop;
import org.nutz.lang.Lang;
import org.nutz.lang.LoopException;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;

import cn.com.whye.core.enums.Enums;
import cn.com.whye.core.query.OrderType;
import cn.com.whye.core.query.Page;
import cn.com.whye.core.service.IBaseService;
import cn.com.whye.core.utils.Constant;
import cn.com.whye.core.utils.Dics;
import cn.com.whye.core.utils.InvokeUtil;
import cn.com.whye.core.utils.ParseUtil;
import cn.com.whye.core.utils.ProcType;
import cn.com.whye.core.utils.StringUtil;
import cn.com.whye.export.annotation.ExportDic;
import cn.com.whye.export.annotation.ExportFmt;
import cn.com.whye.export.format.Formator;
import cn.com.whye.system.utils.Codes;

@IocBean(name = "baseService", args = { "refer:dao" })
public class BaseServiceImpl extends CommonService implements IBaseService {

	protected final Log log = Logs.getLog(this.getClass());
	
	protected Dao dao;

	private final Lock lock = new ReentrantLock();
	
	public BaseServiceImpl(){
	}
	
	public BaseServiceImpl(Dao dao){
		this.dao = dao;
	}

	public long getNextVal(final String key, long defaultValue) {
		synchronized(key) {
			if(Strings.isBlank(key)) return -1;
			
			Record r = dao.fetch("sys_seq", Cnd.where("code", "=", key));
			if(r != null && r.containsKey("value")) {
				return ParseUtil.toLong(r.get("value"), defaultValue);
			} else {
				return defaultValue;
			}
		}
	}
	
	public long setNextVal(final String key) {
		lock.lock();
		try {
			if(Strings.isBlank(key)) return -1;
			Record r = dao.fetch("sys_seq", Cnd.where("code", "=", key));
			if(r != null && r.containsKey("value")) {
				final long nextVal = Long.valueOf(r.get("value").toString()) + 1;
				dao.update("sys_seq", Chain.makeSpecial("value", "+1"), Cnd.where("code", "=", key));
				return nextVal;
			} else {
				dao.insert("sys_seq", Chain.make("code", key).add("value", 1L));
				return 1L;
			}
		} finally {
			lock.unlock();
		}
	}
	
	/**
	 * 执行存储过程
	 * 
	 * @param procName	存储过程名称
	 * @param inParams	存储过程输入参数集合
	 */
	public void call(final String procName, final Map<String, Object> inParams) {
		dao.run(new ConnCallback() {
		   public void invoke(Connection conn) throws Exception {
			   final int paramCount = Lang.isEmpty(inParams) ? 0 : inParams.size();
			   final String symols = StringUtil.substringBeforeLast(Strings.dup("?,", paramCount), ",");
			   final String callSql = String.format("{ call %s(%s) }", procName, symols);
			   
			   CallableStatement cstmt = conn.prepareCall(callSql);
			   //设置输入参数
			   if(paramCount > 0 && !Lang.isEmpty(inParams)) {
				   for(Map.Entry<String, Object> param : inParams.entrySet()) {
					   cstmt.setObject(param.getKey(), param.getValue());
				   }
			   }
			   // true ：有结果集，false ：无结果集
			   cstmt.execute();
		   }
		});
	}
	
	/**
	 * 执行存储过程
	 * 
	 * @param procName	存储过程名称
	 * @param inParams	存储过程输入参数集合
	 * @param outParams	存储过程输出参数集合
	 * @return 	返回输出参数集合的key与对应的返回值组成的集合
	 */
	public Map<String, Object> call(final String procName, 
			final Map<String, Object> inParams, final Map<String, ProcType> outParams) {
		final Map<String, Object> values = new HashMap<String, Object>();
		
		dao.run(new ConnCallback() {
		   public void invoke(Connection conn) throws Exception {
			   final int paramCount = (Lang.isEmpty(inParams) ? 0 : inParams.size()) + (Lang.isEmpty(outParams) ? 0 : outParams.size());
			   final String symols = StringUtil.substringBeforeLast(Strings.dup("?,", paramCount), ",");
			   final String callSql = String.format("{ call %s(%s) }", procName, symols);
			   
			   CallableStatement cstmt = conn.prepareCall(callSql);
			   //设置输入参数
			   if(paramCount > 0 && !Lang.isEmpty(inParams)) {
				   for(Map.Entry<String, Object> param : inParams.entrySet()) {
					   cstmt.setObject(param.getKey(), param.getValue());
				   }
			   }
			   
			   //设置输出参数
			   if(paramCount > 0 && !Lang.isEmpty(outParams)) {
				   //java.sql.Types
				   for(Map.Entry<String, ProcType> param : outParams.entrySet()) {
					   cstmt.setObject(param.getKey(), param.getValue().value());
				   }
			   }
			   // true ：有结果集，false ：无结果集
			   cstmt.execute();
			   for(Map.Entry<String, ProcType> param : outParams.entrySet()) {
				   values.put(param.getKey(), cstmt.getObject(param.getKey()));
			   }
		   }
		});
		
		return values;
	}
	
	public <T> Page<T> findPage(Class<T> clazz, Page<T> page, Criteria cri) {
		return findPage(clazz, page, cri, null);
	}
	
	public <T> Page<T> findPage(Class<T> clazz, Page<T> page, Criteria cri, Map<String, String> values) {
		if(dao == null) {
			log.error("Ioc 'dao' failed!");
			return null;
		}
		
		return getPage(clazz, page, cri, values);
	}
	
	public <T> List<T> findList(Class<T> clazz, Map<String, String> values, String orderPropName, OrderType orderType) {
		Criteria cri = getCriteria(clazz, null, values);
		addOrder(cri, orderPropName, orderType);
		return dao.query(clazz, cri);
	}
	
	public <T> List<T> findList(Class<T> clazz, Map<String, String> values, Map<String, OrderType> orderMap) {
		Criteria cri = getCriteria(clazz, null, values);
		addOrders(cri, orderMap);
		return dao.query(clazz, cri);
	}
	
	public <T> List<Map<String, String>> findMapList(final Class<T> clazz, 
			Map<String, String> values, Map<String, OrderType> orderMap, final Collection<String> propNames) {
		if(Lang.isEmpty(propNames)) {
			return null;
		}
		
		Criteria cri = getCriteria(clazz, null, values);
		addOrders(cri, orderMap);
		
		final List<Map<String, String>> list = new LinkedList<Map<String, String>>();
		dao.each(clazz, cri, null, new Each<T>() {
			@Override
			public void invoke(int index, T target, int length) throws ExitLoop,
					ContinueLoop, LoopException {
				if(target != null) {
					Map<String, String> values = new LinkedHashMap<String, String>();
					Object value = null;
					String fieldValue = null;
					Class<?> clazz = null;
					String sc = null;
					for(String propName : propNames) {
						clazz = target.getClass();
						
						value = InvokeUtil.getValue(target, propName);
						
						ExportFmt fmt = InvokeUtil.getAnnotation(clazz, ExportFmt.class, propName);
						if(fmt != null) {
							fieldValue = value != null ? Formator.format(fmt.formator(), fmt.pattern(), value) : "";
						} else {
							ExportDic dic = InvokeUtil.getAnnotation(clazz, ExportDic.class, propName);
							if(dic != null) {
								sc = dic.sc();
								if(Constant.SC_DICTIONARY_NAME.equals(sc)) {
									fieldValue = Dics.get(dic.type(), String.valueOf(value));
								} else if(Constant.SC_CODE_NAME.equals(sc)) {
									fieldValue = Codes.get(dic.type(), String.valueOf(value));
								} else if(Constant.SC_ENUM_NAME.equals(sc)) {
									fieldValue = Enums.get(dic.type(), String.valueOf(value));
								}
							} else {
								fieldValue = Strings.sBlank(value, "");
							}
						}
						values.put(propName, fieldValue);
					}
					list.add(values);
				}
			}
		});
		return list;
	}
	
	public <T> List<T> query(Class<T> clazz, Criteria cri) {
		return dao.query(clazz, cri);
	}
	
	public List<Record> query(final String tableName, Criteria cri) {
		return dao.query(tableName, cri);
	}
	
	public <T> T fetch(Class<T> clazz, Criteria cri) {
		return dao.fetch(clazz, cri);
	}
	
	public <T> T fetch(Class<T> clazz, Criteria cri, boolean bornIfNull) {
		T obj = dao.fetch(clazz, cri);
		return (obj == null && bornIfNull) ? InvokeUtil.newInstance(clazz) : obj;
	}
	
	public <T> T fetch(Class<T> clazz, boolean bornIfNull, Object... pks) {
		T obj = dao.fetchx(clazz, pks);
		return (obj == null && bornIfNull) ? InvokeUtil.newInstance(clazz) : obj;
	}
	
	@SuppressWarnings("unchecked")
	public <T> T fetch(Class<T> clazz, String pkName, String pkValue) {
		if(Strings.isBlank(pkName) || Strings.isBlank(pkValue)) {
			return null; 
		}
		
		T obj = dao.fetch(clazz, Cnd.where(pkName, "=", pkValue));
		return obj;
	}
	
	public Record fetch(final String tableName, Criteria cri) {
		return dao.fetch(tableName, cri);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T fetch(Class<T> clazz, String pkValue, boolean bornIfNull) {
		T obj = null;
		if(!Strings.isBlank(pkValue)) {
			obj = dao.fetch(clazz, pkValue);
		}
		return (obj == null && bornIfNull) ? InvokeUtil.newInstance(clazz) : obj;
	}
	
	public <T> T fetch(Class<T> clazz, Map<String, String> values) {
		Criteria cri = getCriteria(clazz, null, values);
		return dao.fetch(clazz, cri);
	}
	
	public <T> T update(T target) {
		if(target == null) return null;
		
		String pkValue = (String)InvokeUtil.getValue(target, "id");
		if(Strings.isBlank(pkValue)) {
			InvokeUtil.setValue(target, "id", UUID.randomUUID());
			target = dao.insert(target);
		} else {
			dao.update(target);
		}
		
		return target;
	}
	
	public <T> T update(T target, String... pks) {
		if(target == null) return null;
		if(pks == null || pks.length == 0) {
			return null;
		}
		
		Criteria cri = Cnd.cri();
		String pkValue = null;
		for(String pkName : pks) {
			pkValue = (String)InvokeUtil.getValue(target, pkName);
			cri.where().andEquals(pkName, pkValue);
		}
		
		Object obj = dao.fetch(target.getClass(), cri);
		if(obj == null) {
			target = dao.insert(target);
		} else {
			dao.update(target);
		}
			
		return target;
	}
	
	@SuppressWarnings("serial")
	public <T> T updateBaseAndLinks(T target, final String linkPropName) {
		return updateBaseAndLinks(target, new ArrayList<String>() {{
			add(linkPropName);
		}});
	}
	
	/**
	 * 多对多映射更新主表及中间表
	 * @param target	主表实体
	 * @param linkPropNames	实体关联属性名称集合
	 */
	public <T> T updateBaseAndLinks(T target, List<String> linkPropNames) {
		if(target == null) return null;
		
		String pkValue = (String)InvokeUtil.getValue(target, "id");
		if(Strings.isBlank(pkValue)) {
			pkValue = UUID.randomUUID().toString();
			InvokeUtil.setValue(target, "id", pkValue);
			target = dao.insert(target);
		} else {
			dao.update(target);
		}
		
		if(!Lang.isEmpty(linkPropNames)) {
			for(String propName : linkPropNames) {
				ManyMany annotation = InvokeUtil.getAnnotation(target.getClass(), ManyMany.class, propName);
				if(annotation != null) {
					final String relation = annotation.relation();
					final String from = annotation.from();
					deleteLinks(relation, from, pkValue);
				}
				dao.insertRelation(target, propName);
			}
		}
	
		return target;
	}
	
	public <T> int delete(T target) {
		return dao.delete(target);
	}
	
	public <T> int deleteAll(Class<T> clazz) {
		return dao.clear(clazz, Cnd.cri());
	}
	
	public <T> int delete(Class<T> clazz, Criteria cri) {
		return dao.clear(clazz, cri);
	}
	
	@SuppressWarnings("unchecked")
	public <T> int delete(Class<T> clazz, String pkValue) {
		if(Strings.isBlank(pkValue)) return 0; 
		return dao.delete(clazz, pkValue);
	}
	
	@SuppressWarnings("unchecked")
	public <T> int delete(Class<T> clazz, String pkName, String pkValue) {
		int count = 0;
		
		if(Strings.isBlank(pkName) || Strings.isBlank(pkValue)) {
			return count; 
		}
		
		T obj = dao.fetch(clazz, Cnd.where(pkName, "=", pkValue));
		count += delete(obj);
		return count;
	}
	
	@SuppressWarnings("unchecked")
	public <T> int delete(Class<T> clazz, String[] pkValues) {
		if(Lang.isEmpty(pkValues)) return 0; 
		
		int sLen = 0;
		for(String id : pkValues) {
			sLen += delete(clazz, id);
		}
		
		return sLen;
	}
	
	@SuppressWarnings("unchecked")
	public <T> int delete(Class<T> clazz, List<String> pkValues) {
		if(Lang.isEmpty(pkValues)) return 0; 
		
		int sLen = 0;
		for(String id : pkValues) {
			sLen += delete(clazz, id);
		}
		
		return sLen;
	}
	
	public <T> int deleteLinks(Class<T> clazz, String id, String regexLinksPropName) {
		if(Strings.isBlank(id)) {
			return -1;
		}
		
		T obj = fetch(clazz, id, false);
		if(obj == null) {
			if(log.isErrorEnabled()) {
				log.errorf("entry not found, id:%s", id);
			}
			return -1;
		}
		
		return deleteLinks(obj, regexLinksPropName);
	}
	
	public <T> int deleteLinks(T obj, String regexLinksPropName) {
		return dao.deleteLinks(obj, regexLinksPropName);
	}
	
	public <T> int deleteLinks(Class<T> clazz, List<String> ids, String regexLinkPropNames) {
		if(Lang.isEmpty(ids)) {
			return -1;
		}
		
		int count = 0;
		for(String id : ids) {
			count += deleteLinks(clazz, id, regexLinkPropNames);
		}
		return count;
	}
	
	public <T> int deleteBaseAndLinks(Class<T> clazz, String id, String regexLinkPropNames) {
		T obj = fetch(clazz, id, false);
		return deleteBaseAndLinks(obj, regexLinkPropNames);
	}
	
	public <T> int deleteBaseAndLinks(T obj, String regexLinksPropName) {
		return dao.deleteWith(obj, regexLinksPropName);
	}
	
	public <T> int deleteBaseAndLinks(Class<T> clazz, List<String> ids, String regexLinksPropName) {
		if(Lang.isEmpty(ids)) {
			return -1;
		}
		
		int count = 0;
		for(String id : ids) {
			count += deleteBaseAndLinks(clazz, id, regexLinksPropName);
		}
		return count;
	}
	
	public <T> int deleteBaseAndLinks(Class<T> clazz, String linkTableName, String pkName, String pkValue) {
		deleteLinks(linkTableName, pkName, pkValue);
		return dao.delete(clazz, pkValue);
	}
	
	public int deleteLinks(String linkTableName, String pkName, Object pkValue) {
		return dao.clear(linkTableName, Cnd.where(pkName, "=", pkValue));
	}
	
	public <T> List<String> findIds(Class<T> clazz, String propName, Object propValue) {
		List<T> list = query(clazz, Cnd.where(propName, "=", propValue));
		
		List<String> ids = new LinkedList<String>();
		for(T obj : list) {
			ids.add((String)InvokeUtil.getValue(obj, "id"));
		}
		
		return ids;
	}
	
	public <T> List<String> findIds(Class<T> clazz, Map<String, String> values) {
		Criteria cri = getCriteria(clazz, null, values);
		List<T> list = dao.query(clazz, cri);
		
		List<String> ids = new LinkedList<String>();
		for(T obj : list) {
			ids.add((String)InvokeUtil.getValue(obj, "id"));
		}
		
		return ids;
	}
	
	public <T> List<T> findAll(Class<T> clazz, String orderPropName, OrderType orderType) {
		OrderBy orderBy = getOrderBy(Cnd.orderBy(), orderPropName, orderType);
		return dao.query(clazz, orderBy);
	}
	
	public <T> List<T> findAll(Class<T> clazz, Map<String, OrderType> ordersMap) {
		OrderBy orderBy = Cnd.orderBy();
		if(!Lang.isEmpty(ordersMap)) {
			for(Map.Entry<String, OrderType> m : ordersMap.entrySet()) {
				getOrderBy(orderBy, m.getKey(), m.getValue());
			}
		}
		return dao.query(clazz, orderBy);
	}
	
	public <T> T findLinks(T obj, String linkPropName, String linkOrderPropName) {
		return dao.fetchLinks(obj, linkPropName, Cnd.orderBy().asc(linkOrderPropName));
	}
	
	public <T> T findBaseAndLinks(Class<T> clazz, String pkValue, String linkPropName, String linkOrderPropName) {
		T obj = dao.fetch(clazz, pkValue);
		obj = dao.fetchLinks(obj, linkPropName, Cnd.orderBy().asc(linkOrderPropName));
		return obj;
	}
	
	public <T> List<T> findAllAndLinks(Class<T> clazz, String orderPropName, String linkPropName, String linkOrderPropName) {
		List<T> list = dao.query(clazz, Cnd.orderBy().asc(orderPropName));
		if(list != null && !list.isEmpty()) {
			for(T base : list) {
				dao.fetchLinks(base, linkPropName, Cnd.orderBy().asc(linkOrderPropName));
			}
		}
		return list;
	}
	
	public <T> String getTreeJsonString(Class<T> clazz) {
		return getTreeJsonString(clazz, null, false);
	}
	
	public <T> String getTreeJsonString(Class<T> clazz, boolean isOpenAll) {
		return getTreeJsonString(clazz, null, isOpenAll);
	}

	public <T> String getTreeJsonString(Class<T> clazz, Map<String, String> values) {
		return getTreeJsonString(clazz, values, false);
	}
	
	@SuppressWarnings("serial")
	public <T> String getTreeJsonString(Class<T> clazz, Map<String, String> values, boolean isOpenAll) {
		Map<String, OrderType> ordersMap = new LinkedHashMap<String, OrderType>(){{
			put("level", OrderType.ASC);
			put("seqno", OrderType.ASC);
		}};
		List<T> list = findList(clazz, values, ordersMap);
		
		final String jsonString = buildTreeJsonString(clazz, list, isOpenAll);
		return jsonString;
	}
	
	/**
	 * 根据代码查询表中是否已存在数据，来判断数据是否重复添加的情况
	 * @param uniquePropName	需要校验唯一性的属性的名称
	 * @param uniquePropValue	需要校验唯一性的属性的值
	 * @param pkValue			当前实体的主键属性值
	 * @return					true：数据已存在，不许重复添加；false：校验通过
	 */
	public <T> boolean checkUnique(Class<T> clazz, String uniquePropName, String uniquePropValue, String pkValue) {
		return checkUnique(clazz, uniquePropName, uniquePropValue, "id", pkValue);
	}
	
	public <T> boolean checkUnique(Class<T> clazz, String uniquePropName, String uniquePropValue, String pkName, String pkValue) {
		T obj = dao.fetch(clazz, Cnd.where(uniquePropName, "=", uniquePropValue));
		if(obj == null) return false;
		
		String id = (String)InvokeUtil.getValue(obj, pkName);
		return (Strings.isBlank(id) || id.equals(pkValue)) ? false : true;
	}
	
	/**
	 * 根据代码查询表中是否已存在数据，来判断数据是否重复添加的情况
	 * @param cri		需要校验的查询条件
	 * @param pkValue	当前实体的主键属性值
	 * @return			true：数据已存在，不许重复添加；false：校验通过
	 */
	public <T> boolean checkUnique(Class<T> clazz, Criteria cri, String pkValue) {
		return checkUnique(clazz, cri, "id", pkValue);
	}
	
	public <T> boolean checkUnique(Class<T> clazz, Criteria cri, String pkName, String pkValue) {
		T obj = dao.fetch(clazz, cri);
		if(obj == null) return false;
		
		String id = (String)InvokeUtil.getValue(obj, pkName);
		return (Strings.isBlank(id) || id.equals(pkValue)) ? false : true;
	}
	
	/**
	 * 根据代码查询表中是否已存在数据，来判断数据是否重复添加的情况
	 * @param type	码表类型值
	 * @param code	当前实体的编码值
	 * @return		true：数据已存在，不许重复添加；false：校验通过
	 */
	public <T> boolean checkCodeUnique(Class<T> clazz, String type, String code, String pkValue) {
		T obj = dao.fetch(clazz, Cnd.where("type", "=", type).and("code", "=", code));
		if(obj == null) return false;
		
		String id = (String)InvokeUtil.getValue(obj, "id");
		return (Strings.isBlank(id) || id.equals(pkValue)) ? false : true;
	}

	@Override
	public Dao getDao() {
		return dao;
	}
	
}
