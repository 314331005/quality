package cn.com.whye.core.service.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.dao.pager.Pager;
import org.nutz.dao.sql.Criteria;
import org.nutz.dao.sql.OrderBy;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.lang.Lang;
import org.nutz.lang.Strings;

import cn.com.whye.core.annotation.TreeDefine;
import cn.com.whye.core.domain.TreeNode;
import cn.com.whye.core.query.FilterType;
import cn.com.whye.core.query.FilterUtil;
import cn.com.whye.core.query.OrderType;
import cn.com.whye.core.query.Page;
import cn.com.whye.core.utils.InvokeUtil;
import cn.com.whye.core.utils.JsonUtil;

public abstract class CommonService {
	
	public abstract Dao getDao();
	
	/**
	 * 
	 * @param orderBy
	 * @param orderPropName
	 * @param orderType
	 * @return
	 */
	protected OrderBy getOrderBy(OrderBy orderBy, String orderPropName, OrderType orderType) {
		if(orderBy == null) {
			orderBy = Cnd.orderBy();
		}
		
		if(OrderType.DESC == orderType) {
			orderBy.desc(orderPropName);
		} else {
			orderBy.asc(orderPropName);
		}
		
		return orderBy;
	}

	/**
	 * 功能：获取分页实例（包括数据总量和当前页数据列表）
	 * @param page  分页实例
	 * @param cri	查询条件
	 */
	@SuppressWarnings("unchecked")
	protected <T> Page<T> getPage(Class<T> clazz, Page<T> page, Criteria cri) {
		return getPage(clazz, page, cri, null);
	}
	
	/**
	 * 功能：获取分页实例（包括数据总量和当前页数据列表）
	 * @param page  分页实例
	 * @param cri	查询条件
	 */
	@SuppressWarnings("unchecked")
	protected <T> Page<T> getPage(Class<T> clazz, Page<T> page, Criteria cri, Map<String, String> values) {
		if (page == null) {
			page = new Page<T>();
		}

		if(cri == null) {
			cri = Cnd.cri();
		}
		
		getCriteria(clazz, cri, values);
		
		Pager pager = getDao().createPager(page.getPageNo(), page.getPageSize());
		page.setTotalCount(getDao().count(clazz, cri));
		
		// 分页排序解析
		addOrders(cri, page.getOrderBy());
		
		List<T> list = getDao().query(clazz, cri, pager);
		page.setResult(list);
		
		return page;
	}
	
	protected void addOrder(Criteria cri, String orderPropName, OrderType orderType) {
		if(!Strings.isBlank(orderPropName)) {
			OrderBy orderBy = cri.getOrderBy();
			if(OrderType.DESC == orderType) {
				orderBy.desc(orderPropName);
			} else {
				orderBy.asc(orderPropName);
			}
		}
	}
	
	protected void addOrders(Criteria cri, Map<String, OrderType> orderMap) {
		if (orderMap != null && !orderMap.isEmpty()) {
			OrderBy orderBy = cri.getOrderBy();
			for (Map.Entry<String, OrderType> m : orderMap.entrySet()) {
				if(OrderType.DESC == m.getValue()) {
					orderBy.desc(m.getKey());
				} else {
					orderBy.asc(m.getKey());
				}
			}
		}
	}

	/**
	 * 功能：获取添加过滤条件后的Criteria实例
	 * 
	 * @param clazz 实体类型
	 * @param values 指定格式的过滤条件，若为null则查询所有
	 * @return
	 */
	protected <T> Criteria getCriteria(Class<T> clazz, Criteria cri, Map<String, String> values) {
		if(cri == null) {
			cri = Cnd.cri();
		}
		
		if (values != null && !values.isEmpty()) {
			for (Map.Entry<String, String> param : values.entrySet()) {
				addCriteriaFilter(cri, param.getKey(), param.getValue());
			}
		}

		return cri;
	}
	
	/**
	 * 功能：通过已存在的 Criteria 实例添加过滤条件
	 * 
	 * @param cri 查询条件
	 * @param filterParamName 指定格式的字符串，模板格式如：ft_{FilterType}_{ParamType}_{实体属性名称}
	 * @param filterParamValue 请求域中参数的属性值
	 */
	protected void addCriteriaFilter(Criteria cri,
			final String filterParamName, final String filterParamValue) {
		Object[] params = FilterUtil.getFilterParamValue(filterParamName,
				filterParamValue);

		if (Lang.isEmptyArray(params) 
				|| params.length < 3 || params[2] == null) {
			return;
		}

		addCriteriaFilterParams(cri, (FilterType) params[0],
				(String) params[1], params[2]);
	}

	/**
	 * 功能：根据检索类型为过滤器传递实际的属性名称和属性值来实现过滤检索数据的功能
	 * 
	 * @param cri 查询条件
	 * @param ft  枚举检索类型
	 * @param propName 	属性名
	 * @param value		属性值
	 */
	private void addCriteriaFilterParams(Criteria cri, FilterType ft,
			String propName, Object value) {
		SqlExpressionGroup expr = cri.where();

		switch ((FilterType) ft) {
		case EQ:
			expr.andEquals(propName, value);
			break;
		case LIKEL:
			expr.andLikeR(propName, filterWord4Like((String)value));
			break;
		case LIKER:
			expr.andLikeL(propName, filterWord4Like((String)value));
			break;
		case LIKEA:
			expr.andLike(propName, filterWord4Like((String)value), false);
			break;
		case LIKEAI:
			expr.andLike(propName, filterWord4Like((String)value), true);
			break;
		case GT:
			expr.and(propName, ">", value);
			break;
		case GE:
			expr.and(propName, ">=", value);
			break;
		case LT:
			expr.and(propName, "<", value);
			break;
		case LE:
			expr.and(propName, "<=", value);
			break;
		case NE:
			expr.andNotEquals(propName, value);
			break;
		default:
			break;
		}
		
	}
	
	private String filterWord4Like(String value) {
		return value.replaceAll("%", "*.&^#@").replaceAll("_", "*.&^#@");
	}
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list) {
		Collection<TreeNode> result = buildTreeStructure(clazz, list, false);
		return Lang.isEmpty(result) ? "[]".intern() : JsonUtil.toJson(result);
	}
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list, boolean isOpenAll) {
		Collection<TreeNode> result = buildTreeStructure(clazz, list, isOpenAll);
		return Lang.isEmpty(result) ? "[]".intern() : JsonUtil.toJson(result);
	}
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list, final String key, final String pkey) {
		Collection<TreeNode> result = buildTreeStructure(clazz, list, key, pkey, false);
		return Lang.isEmpty(result) ? "[]".intern() : JsonUtil.toJson(result);
	}
	
	public <T> String buildTreeJsonString(Class<T> clazz, Collection<T> list, final String key, final String pkey, boolean isOpenAll) {
		Collection<TreeNode> result = buildTreeStructure(clazz, list, key, pkey, isOpenAll);
		return Lang.isEmpty(result) ? "[]".intern() : JsonUtil.toJson(result);
	}
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list) {
		return buildTreeStructure(clazz, list, "id", "pid", false);
	}
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list, boolean isOpenAll) {
		return buildTreeStructure(clazz, list, "id", "pid", isOpenAll);
	}
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list, final String key, final String pkey) {
		return buildTreeStructure(clazz, list, key, pkey, false);
	}
	
	public <T> Collection<TreeNode> buildTreeStructure(Class<T> clazz, Collection<T> list, final String key, final String pkey, boolean isOpenAll) {
		List<TreeNode> result = new LinkedList<TreeNode>();
		Map<String, TreeNode> map = new HashMap<String, TreeNode>();

		String keyVal = null;
		String pkeyVal = null;
		String textVal = null;
		String codeVal = null;
		String linkVal = null;
		int isValid = 1;
		
		TreeDefine treeDef = InvokeUtil.getTreeNodeDefine(clazz);
		final String textName = treeDef.text();
		final String codeName = treeDef.value();
		final String linkName = treeDef.url();
		final String validName = treeDef.valid();
		
		for (T obj : list) {
			keyVal = (String)InvokeUtil.getValue(obj, key);
			pkeyVal = (String)InvokeUtil.getValue(obj, pkey);
			textVal = (String)InvokeUtil.getValue(obj, textName);
			if(!Strings.isBlank(codeName)) {
				codeVal = (String)InvokeUtil.getValue(obj, codeName);
			}
			if(!Strings.isBlank(linkName)) {
				linkVal = (String)InvokeUtil.getValue(obj, linkName);
			}
			if(!Strings.isBlank(validName)) {
				isValid = (Integer)InvokeUtil.getValue(obj, validName);
			}
			map.put(keyVal, new TreeNode(keyVal, pkeyVal, textVal, codeVal, linkVal, isValid == 1 ? true : false));
		}
		
		for (T obj : list) {
			TreeNode target = map.get((String)InvokeUtil.getValue(obj, key));
			TreeNode parent = map.get((String)InvokeUtil.getValue(obj, pkey));
			if(isOpenAll) {
				if(parent != null) {
					parent.setOpen(true);
				} 
				target.setOpen(true);
			}
			if (parent == null) {
				target.setOpen(true);
				result.add(target);
			} else {
				parent.addChild(target);
			}
		}
		
		return result;
	}

}
