package cn.com.whye.core.unitest;

import org.nutz.http.Request;
import org.nutz.http.Response;
import org.nutz.http.Request.METHOD;
import org.nutz.http.sender.PostSender;
import org.nutz.ioc.Ioc;
import org.nutz.ioc.impl.NutIoc;
import org.nutz.ioc.loader.combo.ComboIocLoader;

/**
 * 单元测试基类
 * @author 	wq
 * @date	2014-10-27
 */
public class BaseUnitTest {
	
	private Ioc ioc = null;

	public BaseUnitTest() {
		try {
			ioc = new NutIoc(new ComboIocLoader(
				"*org.nutz.ioc.loader.json.JsonLoader", "ioc/",
				"*org.nutz.ioc.loader.annotation.AnnotationIocLoader",
				"cn.com.whye"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public <T> T get(Class<T> type, final String name) {
		return ioc.get(type, name);
	}
	
	public String getResult(String url) {
		return getResult(url, METHOD.POST);
	}
	
	public String getResult(String url, METHOD method) {
		Request request = Request.create(url, method);
		PostSender sender = new PostSender(request);
		Response resp = sender.send();
		return resp.getContent();
	}

	public Ioc getIoc() {
		return ioc;
	}
	
}
