package cn.com.whye.core.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.nutz.json.JsonFormat;
import org.nutz.lang.Strings;
import org.nutz.mvc.ActionContext;
import org.nutz.mvc.ActionFilter;
import org.nutz.mvc.Mvcs;
import org.nutz.mvc.View;
import org.nutz.mvc.view.ServerRedirectView;
import org.nutz.mvc.view.UTF8JsonView;

import cn.com.whye.core.utils.DwzUtil;

/**
 * 功能：用户登录拦截器
 * 说明：只拦截控制器类
 * @author 	wq
 * @date 	2014-09-22
 */
public class LoginFilter implements ActionFilter {
	
	/**
	 * 不拦截路径的正则表达式
	 */
	private String excludeRegex;
	
	private String name;
	
	private String path;
	
	public LoginFilter(String name, String path) {
		this.name = name;
		this.path = path;
	}
	
	public LoginFilter(String excludeRegex, String name, String path) {
		this.excludeRegex = excludeRegex;
		this.name = name;
		this.path = path;
	}

	@Override
	public View match(ActionContext context) {
		HttpServletRequest req = context.getRequest();
		final String url = Mvcs.getRequestPath(req);
		
		if(url.contains("/login") || url.contains("/logout")) {
			return null;
		}
		
		//正则表达式匹配项不做正则校验
		if(!Strings.isBlank(excludeRegex)) {
			Pattern p = Pattern.compile(excludeRegex);
			Matcher m = p.matcher(url);
			if(m != null && m.find()) {
				return null;
			}
		}
		
		HttpSession session = Mvcs.getHttpSession(false);
		if(session == null || null == session.getAttribute(name)) {
			boolean isAjax = req.getHeader("x-requested-with") != null ? true : false;
			if(isAjax) { // AJAX请求
				UTF8JsonView jsonView = new UTF8JsonView(JsonFormat.compact());
				jsonView.setData(DwzUtil.sessionTimeout("当前会话超时，请重新登录！"));
				return jsonView;
			} else { // 普通HTTP请求
				return new ServerRedirectView(path);
			}
		}
		
		return null;
	}

}
