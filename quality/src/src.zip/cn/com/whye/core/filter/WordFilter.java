package cn.com.whye.core.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.nutz.lang.Strings;
import org.nutz.mvc.ActionContext;
import org.nutz.mvc.ActionFilter;
import org.nutz.mvc.Mvcs;
import org.nutz.mvc.View;

import cn.com.whye.core.http.MyHttpServletRequest;

/**
 * 功能：请求域参数内容特殊字符过滤
 * 
 * @author 	wq
 * @date 	2014-09-22
 */
@SuppressWarnings("unchecked")
public class WordFilter implements ActionFilter {

	/**
	 * 不拦截路径的正则表达式
	 */
	private String excludeRegex;
	
	public WordFilter() {
	}
	
	public WordFilter(String excludeRegex) {
		this.excludeRegex = excludeRegex;
	}
	
	@Override
	public View match(ActionContext context) {
		HttpServletRequest req = context.getRequest();
		final String url = Mvcs.getRequestPath(req);
		
		//正则表达式匹配项不做正则校验
		if(!Strings.isBlank(excludeRegex)) {
			Pattern p = Pattern.compile(excludeRegex);
			Matcher m = p.matcher(url);
			if(m != null && m.find()) {
				return null;
			}
		}
		
		context.setRequest(new MyHttpServletRequest(req));
		return null;
	}

}