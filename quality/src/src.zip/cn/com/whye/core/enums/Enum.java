package cn.com.whye.core.enums;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 该注解应声明在枚举类上，用于程序中码表解析，避免硬编码
 * 说明：声明在其它处无效
 * @author 	wq
 * @date	2015-02-13
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Enum {

	public String value();
	
}
