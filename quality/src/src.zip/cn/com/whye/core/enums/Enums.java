package cn.com.whye.core.enums;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.nutz.lang.Lang;
import org.nutz.lang.Strings;
import org.nutz.mvc.annotation.IocBy;
import org.nutz.resource.Scans;

import cn.com.whye.MainModule;
import cn.com.whye.core.utils.Constant;
import cn.com.whye.core.utils.InvokeUtil;

/**
 * 枚举码表辅助类，用于初始化时将定义的枚举信息
 * @author 	wq
 * @date	2015-02-13
 */
@SuppressWarnings("unchecked")
public class Enums {
	
	private static final Map<String, Map<String, String>> enumsMap = new HashMap<String, Map<String, String>>();
	
	/**
	 * 扫描所有标识为导出的实体
	 * 说明：默认扫描 MainModule 类的 IocBy注解的 第4个参数
	 * @param sc
	 */
	public static void scan(ServletContext sc) {
		IocBy iocBy = InvokeUtil.getAnnotation(MainModule.class, IocBy.class);
		String[] args = iocBy.args();
		if(args != null && args.length >= 4) {
			scan(sc, args[3]); 
		}
	}
	
	/**
	 * 扫描所有标记Enum注解的枚举类
	 * @param sc
	 * @param scanPackage
	 */
	public static void scan(ServletContext sc, String scanPackage) {
		List<Class<?>> domains = Scans.me().scanPackage(scanPackage);
		
		Enum anno = null;
		Map<String, String> values = null;
		for(Class<?> clazz : domains) {
			anno = clazz.getAnnotation(Enum.class);
			if(anno != null) {
				values = new LinkedHashMap<String, String>();
				
				Object[] fields = clazz.getEnumConstants();
				for(Object field : fields) {
					IBaseEnum e = (IBaseEnum)field;
					values.put(e.code(), e.text());
				}
				enumsMap.put(anno.value(), values);
			}
		}
		
		sc.setAttribute(Constant.SC_ENUM_NAME, enumsMap);
	}
	
	/**
	 * 获取所有标记Enum注解的枚举类
	 * @param sc
	 * @param type
	 * @return
	 */
	public static final String get(String type, String code) {
		if(Strings.isBlank(type) || Strings.isBlank(code)) {
			return "".intern();
		}
		
		Map<String, String> values = enumsMap.containsKey(type) ? enumsMap.get(type) : null;
		return !Lang.isEmpty(values) ? Strings.sBlank(values.get(code), "") : "".intern();
	}
	
}
