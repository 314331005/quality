package cn.com.whye.core.enums;

public interface IBaseEnum {

	public String name();
	
	public String code();
	
	public String text();
	
}
