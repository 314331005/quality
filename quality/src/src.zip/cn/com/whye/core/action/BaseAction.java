package cn.com.whye.core.action;

import java.util.Collection;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.nutz.http.Request;
import org.nutz.http.Response;
import org.nutz.http.Request.METHOD;
import org.nutz.http.sender.PostSender;
import org.nutz.lang.Mirror;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mvc.Mvcs;

import cn.com.whye.core.query.OrderType;
import cn.com.whye.core.query.Page;
import cn.com.whye.core.utils.Constant;
import cn.com.whye.core.utils.RegexUtil;
import cn.com.whye.core.utils.StringUtil;
import cn.com.whye.system.domain.SysMenu;
import cn.com.whye.system.domain.SysUser;

/**
 * 功能：控制器基类，提供通用的处理方法
 * 说明：无特殊情况，所有的控制器类都应继承这个类
 * @author 	wq
 * @date	2014-09-16
 */
public class BaseAction {

	private Log log = Logs.getLog(this.getClass());
	
	protected HttpServletRequest getRequest() {
		return Mvcs.getReq();
	}
	
	protected HttpServletResponse getResponse() {
		return Mvcs.getResp();
	}
	
	/**
	 * 功能：获取相同前缀的请求域参数
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected Map<String, String> getRequestParams() {
		HttpServletRequest request = getRequest();
		Map<String, String[]> params = request.getParameterMap();
		
		Map<String, String> values = new LinkedHashMap<String, String>();
		if(params != null && !params.isEmpty()) {
			String paramKey = null;
			String paramValue = null;
			
			for(Map.Entry<String, String[]> param : params.entrySet()) {
				paramKey = param.getKey();
				
				if(RegexUtil.isFilterParam(paramKey)) {
					paramValue = request.getParameter(paramKey);
					if(Strings.isBlank(paramValue)) {
						continue;
					}
					values.put(paramKey, Strings.trim(paramValue));
				}
			}
		}
		
		return values;
	}
	
	/**
	 * 功能：获取相同前缀的请求域参数（已去除前缀）
	 * 说明：请求域参数如：page.pageSize，返回处理后的参数如：pageSize
	 * @param request
	 * @param prefix	前缀如：page.pageSize 该值为：page.
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getRequestParams(String prefix) {
		prefix = Strings.sBlank(prefix);
		
		Map<String, String> params = new LinkedHashMap<String, String>();
		
		HttpServletRequest request = getRequest();
		
		Enumeration<String> paramNames = request.getParameterNames();
		if(paramNames != null) {
			while (paramNames.hasMoreElements()) {
				String paramName = (String) paramNames.nextElement();
				if (Strings.isBlank(prefix) || paramName.startsWith(prefix)) {
					String suffix = StringUtil.substringAfter(paramName, prefix);
					String[] values = request.getParameterValues(paramName);
					if (values == null || values.length == 0) {
						// Do nothing, no values found.
					} else if (values.length > 1) {
						params.put(suffix, StringUtil.join(values, ","));
					} else {
						params.put(suffix, values[0]);
					}
				}
			}
		}
		
		return params;
	}
	
	/**
	 * 功能：获取页面传递过来的分页相关信息
	 * @param request
	 * @param prefix	前缀如：page.pageSize 该值为：page.
	 * @param orderBy	实体属性名称，按该属性排序
	 * @param order		顺序或倒序
	 * @return
	 */
	public <T> Page<T> getPage(String prefix, String orderBy, OrderType orderType) {
		Page<T> page = getPage(prefix);
		
		if(!Strings.isBlank(orderBy)) {
			page.addOrder(orderBy, orderType == null ? OrderType.ASC : orderType);
		}
		
		String orders = Mvcs.getReq().getParameter("orders");
		if(!Strings.isBlank(orders)){
			page.setOrders(orders);
		}
 	
		return page;
	}
	
	/**
	 * 功能：根据请求域参数初始化分页对象
	 * @param request
	 * @param prefix
	 * @return
	 */
	public <T> Page<T> getPage(String prefix) {	
		Page<T> page = new Page<T>();
		
		Map<String, String> filterParamMap = getRequestParams(prefix);
		for (Map.Entry<String, String> entry : filterParamMap.entrySet()) {
			String name = entry.getKey();
			String value = entry.getValue();
			try {
				Mirror<Page<T>> mirror = Mirror.me(page);
				mirror.setValue(page, name, value);
			} catch (Exception e) {
				if(log.isErrorEnabled()) {
					log.errorf("getPage Exception : %s", e.getMessage());
				}
			}			
		}
		
		return page;
	}
	
	public String getResult(String url) {
		return getResult(url, METHOD.POST);
	}
	
	public String getResult(String url, METHOD method) {
		Request request = Request.create(url, method);
		PostSender sender = new PostSender(request);
		Response resp = sender.send();
		return resp.getContent();
	}
	
	protected String getContextPath() {
		return Mvcs.getServletContext().getContextPath();
	}
	
	protected SysUser getSessionSysUser() throws Exception {
		HttpSession session = Mvcs.getHttpSession(false);
		if(session == null) {
			return null;
		}
		SysUser user = (SysUser)session.getAttribute(Constant.SYS_USER);
		if(user == null) {
			throw new Exception("当前会话已超时，请重新登录系统！");
		}
		return user;
	}
	
	protected String getSessionUname() throws Exception {
		SysUser user = getSessionSysUser();
		return (user != null ? user.getName() : null);
	}
	
	protected String getSessionUDeptCode() {
		String deptCode = "".intern();
		try {
			SysUser user = getSessionSysUser();
			if(user != null) {
				deptCode = user.getDeptCode();
			}
		} catch(Exception e) {
		}
		return deptCode;
	}
	
	protected String getSessionUid() throws Exception {
		SysUser user = getSessionSysUser();
		return (user != null ? user.getId() : null);
	}
	
	protected void setSessionUser(SysUser user, Collection<SysMenu> menus) {
		HttpSession session = Mvcs.getHttpSession(true);
		if(session != null) {
			session.setAttribute(Constant.SYS_USER, user);
			session.setAttribute(Constant.SYS_USER_MENU, menus);
		}
	}
	
	protected void setSessionUser(SysUser user, String treeHTML) {
		HttpSession session = Mvcs.getHttpSession(true);
		if(session != null) {
			session.setAttribute(Constant.SYS_USER, user);
			session.setAttribute(Constant.SYS_USER_MENU, treeHTML);
		}
	}
	
	protected void setSessionUserMenu(SysUser user, String treeHTML) {
		setSessionUser(user, treeHTML);
	}
	
	protected void removeSessionUser() {
		HttpSession session = Mvcs.getHttpSession(false);
		if(session != null && session.getAttribute(Constant.SYS_USER) != null) {
			session.removeAttribute(Constant.SYS_USER);
			session.removeAttribute(Constant.SYS_USER_MENU);
			session.invalidate();
		}
	}
	
}
