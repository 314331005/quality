package cn.com.whye.core.tlds;

import java.util.LinkedList;
import java.util.List;


/**
 * JSTL自定义函数后台处理类 
 * 说明：对应jstl标签库文件：WEB-INF/tld/whye_list.tld
 * 
 * @author 	wq
 * @date 	2014-09-18
 */
public class ListTld {

	/**
	 * 初始化一个空的List实例
	 */
	public static List<Object> init() {
		return new LinkedList<Object>();
	}
	
	/**
	 * 向list中添加元素
	 */
	public static List<Object> add(List<Object> list, Object obj) {
		if(list == null) {
			list = init();
		}
		list.add(obj);
		return list;
	}
	
}
