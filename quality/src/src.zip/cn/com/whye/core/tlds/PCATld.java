package cn.com.whye.core.tlds;

import org.nutz.lang.Strings;

import cn.com.whye.core.utils.Constant;
import cn.com.whye.system.utils.Codes;

/**
 * JSTL自定义函数后台处理类 
 * 说明：对应jstl标签库文件：WEB-INF/tld/whye_pca.tld
 * 
 * @author 	wq
 * @date 	2014-12-09
 */
@SuppressWarnings("unchecked")
public class PCATld {
	
	private static final String getName(String code) {
		return Strings.sBlank(Codes.get(Constant.SC_CODE_PCA_ALL, code));
	}
	
	public static java.lang.String get(String code) {
		return Strings.isBlank(code) ? "".intern() : getName(code);
	}
	
	public static java.lang.String pca(String province, String city, String area, String splitStr) {
		splitStr = Strings.sBlank(splitStr);
		StringBuffer sb = new StringBuffer();
		return sb.append(get(province))
				 .append(splitStr)
				 .append(get(city))
				 .append(splitStr)
				 .append(get(area))
				 .toString()
				 .intern();
	}

}
