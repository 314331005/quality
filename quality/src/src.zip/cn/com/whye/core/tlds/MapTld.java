package cn.com.whye.core.tlds;

import org.nutz.lang.Strings;

/**
 * JSTL自定义函数后台处理类 
 * 说明：对应jstl标签库文件：WEB-INF/tld/whye_map.tld
 * 
 * @author 	wq
 * @date 	2014-09-18
 */
@SuppressWarnings("unchecked")
public class MapTld {
	
	public static boolean containsKey(java.util.Map map, java.lang.String key) {
		return (key != null && map != null && map.size() > 0 && map.containsKey(key));
	}

	public static java.lang.Object get(java.util.Map map, String key) {
		return get(map, key, "");
	}

	public static java.lang.Object get(java.util.Map map, String key, Object defaultValue) {
		return containsKey(map, key) ? map.get(key) : Strings.sBlank(defaultValue);
	}
	
	public static void put(java.util.Map map, java.lang.String key, java.lang.Object value) {
		if(map != null && key != null) {
			map.put(key, value);
		} 
	}

}
