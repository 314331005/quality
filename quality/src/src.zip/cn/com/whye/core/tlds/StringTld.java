package cn.com.whye.core.tlds;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.LinkedList;

import org.nutz.lang.Strings;

import cn.com.whye.core.utils.InvokeUtil;
import cn.com.whye.core.utils.StringUtil;

/**
 * JSTL自定义函数后台处理类 
 * 说明：对应jstl标签库文件：WEB-INF/tld/whye_str.tld
 * 
 * @author 	wq
 * @date 	2014-09-18
 */
public class StringTld {
	
	private static final NumberFormat nf = new DecimalFormat("#0.0");
	
	public static String leftPad(Object str, int length, String padChar) {
		return Strings.alignRight(str, length, 
				Strings.isBlank(padChar) ? '\0' : padChar.charAt(0));
	}
	
	public static String rightPad(Object str, int width, String padChar) {
		return Strings.alignLeft(str, width, 
				Strings.isBlank(padChar) ? '\0' : padChar.charAt(0));
	}
	
	public static String toString(Object value) {
		return Strings.sBlank(value, "");
	}
	
	public static String substringAfterLast(Object str, String separator) {
		if(str == null) return "";
		return StringUtil.substringAfterLast(str.toString(), separator);
	}
	
	public static String format(double value, int length) {
		String str = nf.format(value);
		if(str.indexOf(".") != -1 && str.length() > length) {
			String left = StringUtil.substringBefore(str, ".");
//			String right = StringUtil.substringAfterLast(str, ".");
			return left;
		}
		return str;
	}
	
	/**
	 * 按指定长度截取字符串
	 * @param str
	 * @param length
	 * @return
	 */
	public static String cut(String str, int length) {
		if (Strings.isBlank(str)) {
			return "";
		}
		return str.length() > length ? Strings.cutRight(str, length, '\0').concat("...") : str;
	}
	
	/**
	 * 判断一个字符串是否为另一个字符串的子串
	 * @param fullStr	"1,23,134,34,2"
	 * @param splitStr	分隔符 ,
	 * @param validStr	子串	  23
	 * @return
	 */
	public static boolean contains(String fullStr, String splitStr, Object validStr) {
		return fullStr != null && splitStr != null && validStr != null 
				&& ((splitStr+fullStr+splitStr).indexOf(splitStr+validStr+splitStr) != -1);
	}
	
	public static String join(Object[] array, String splitStr) {
		if(array == null || array.length == 0) return "";
		if(splitStr == null || splitStr.trim().length() == 0) splitStr = ",";
		return StringUtil.join(array, splitStr);
	}
	
	public static String join(Collection<?> collection, String splitStr) {
		if(collection == null || collection.size() == 0) return "";
		if(splitStr == null || splitStr.trim().length() == 0) splitStr = ",";
		return StringUtil.join(collection, splitStr);
	}
	
	public static String join(Collection<?> collection, String propName, String splitStr) {
		if(collection == null || collection.size() == 0) return "";
		if(splitStr == null || splitStr.trim().length() == 0) splitStr = ",";
		Collection<String> propValues = new LinkedList<String>();
		for(Object obj : collection) {
			if(obj == null) {
				continue;
			}
			propValues.add((String)InvokeUtil.getValue(obj, propName));
		}
		return join(propValues, splitStr);
	}
	
	public static String encode(String str) {
		try {
			if(str == null) return null;
			return java.net.URLEncoder.encode(str, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return "";
		}
	}
	
	public static String decode(String str) {
		try {
			if(str == null) return null;
			return java.net.URLDecoder.decode(str, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return "";
		}
	}
	
}
