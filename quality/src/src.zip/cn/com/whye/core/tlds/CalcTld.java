package cn.com.whye.core.tlds;



/**
 * JSTL自定义函数后台处理类 
 * 说明：对应jstl标签库文件：WEB-INF/tld/whye_calc.tld
 * 
 * @author 	wq
 * @date 	2014-09-24
 */
public class CalcTld {

	public static double max(double a, double b) {
		return Math.max(a, b);
	}
	
	public static double min(double a, double b) {
		return Math.min(a, b);
	}
	
}
