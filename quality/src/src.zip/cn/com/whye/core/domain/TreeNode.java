package cn.com.whye.core.domain;

import java.util.LinkedList;
import java.util.List;

/**
 * 树形结构数据辅助实体信息
 * @author 	wq
 * @date 	2014-09-17
 */
public class TreeNode {
	
	private String id;
	
	private String pid;
	
	private String text;
	
	private String value;
	
	private List<TreeNode> childs = new LinkedList<TreeNode>();
	
	private String link;
	
	private boolean open = false;
	
	private boolean valid = true;
	
	public TreeNode() {
	}

	public TreeNode(String id, String pid, String text) {
		this.id = id;
		this.pid = pid;
		this.text = text;
	}
	
	public TreeNode(String id, String pid, String text, boolean valid) {
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.valid = valid;
	}

	public TreeNode(String id, String pid, String text, String value, boolean valid) {
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.value = value;
		this.valid = valid;
	}

	public TreeNode(String id, String pid, String text, String value, String link, boolean valid) {
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.value = value;
		this.link = link;
		this.valid = valid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void addChild(TreeNode child) {
//		child.setParent(this);
		childs.add(child);
	}
	
	public List<TreeNode> getChilds() {
		return childs;
	}

	public void setChilds(List<TreeNode> childs) {
		this.childs = childs;
	}
	
	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public boolean isOpen() {
		return open;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

}
