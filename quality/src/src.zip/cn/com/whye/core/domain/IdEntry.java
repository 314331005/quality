package cn.com.whye.core.domain;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Name;

/**
 * 实体主键通用性声明
 * @author 	wq
 * @date 	2014-09-16
 */
public class IdEntry {

	/**
	 * 说明：因@Id要求字段类型必须为数值型，故主键字段必须声明为@Name
	 */
	@Name
//	@Prev({
//		@SQL(db=DB.MYSQL, value="select uuid() ID")
//	})
	@Column("ID")
	@Comment("主键")
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final IdEntry other = (IdEntry) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
}
