package cn.com.whye.core.query;

/**
 * 检索类型枚举类
 * @author 	wq
 * @date	2014-09-16
 */
public enum FilterType {

	EQ,// equal
	LIKEL,// left like
	LIKELI,// left like ignore case
	LIKER,// right like
	LIKERI,// right like ignore case
	LIKEA,// all like
	LIKEAI,// all like ignore case
	GT,// great than
	GE,// great than equal
	LT,// less than
	LE,// less than equal
	NE,// not equal
	IN,// in
	NI;// not in
	
}
