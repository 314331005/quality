package cn.com.whye.core.query;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.nutz.lang.Strings;


/**
 * 分页工具类
 * @author 	wq
 * @date	2014-09-16
 */
@SuppressWarnings("unchecked")
public class Page<T> {

	/**
	 * 当前页码
	 */
	private int pageNo = 1;
	
	/**
	 * 每页数据量
	 */
	private int pageSize = 15;
	
	/**
	 * 数据总量
	 */
	private long totalCount = -1;
	
	/**
	 * 显示页码数
	 */
	private int pageShowNum = 5;
	
	/**
	 * 当前页的数据列表
	 */
	private List<T> result = new LinkedList<T>();
	
	/**
	 * 排序字符串，格式如：propName1 desc, propName2 asc
	 * 说明：若使用该属性，应该从前台页面中传递
	 */
	private String orders;
	
	/**
	 * 属性排序集合
	 * 说明：若使用该属性，应该从后台代码中设置
	 */
	private Map<String, OrderType> orderBy = new LinkedHashMap<String, OrderType>();
	
	public Page() {
	}

	public Page(int pageSize) {
		this.pageSize = pageSize;
	}

	public Page<T> addOrder(String orderBy, OrderType orderType) {
		if(!Strings.isBlank(orderBy) 
				&& orderType != null) {
			this.orderBy.put(orderBy, orderType);
		}
		return this;
	}

	public Map<String, OrderType> getOrderBy() {
		return orderBy;
	}

	/**
	 * 将页面传递过来的排序字符串解析并放入orderBy集合供持久层处理
	 * @return
	 */
	public void setOrders(String orders) {
		if(!Strings.isBlank(orders)) {
			String[] orderArr = Strings.splitIgnoreBlank(orders, ",");
			OrderType orderType = OrderType.ASC;
			String propName = null;
			String[] propsArr = null;
			for(String order : orderArr) {
				if(!Strings.isBlank(order)) {
					propsArr = Strings.splitIgnoreBlank(order, " ");
					propName = propsArr[0];
					if(!Strings.isBlank(propName)) {
						orderType = "desc".equalsIgnoreCase(propsArr[1]) ? OrderType.DESC : OrderType.ASC;
						orderBy.put(propName, orderType);
					}
				}
			}
		}
		
		this.orders = orders;
	}
	
	/**
	 * 将orderBy集合中的排序内容转换为字符串，内容如：
	 * 	propName1 desc, propName2 asc, propName3, propName4 desc
	 * @return
	 */
	public String getOrders() {
		if(!Strings.isBlank(orders)) {
			return orders;
		} else {
			if(!orderBy.isEmpty()) {
				StringBuffer sb = new StringBuffer();
				for(Map.Entry<String, OrderType> m : orderBy.entrySet()) {
					sb.append(m.getKey()).append(" ").append(m.getValue().toString()).append(",");
				}
				return sb.toString();
			}
		}
		return "".intern();
	}

	public int getPageShowNum() {
		return Math.max(pageShowNum, 3);
	}

	public void setPageShowNum(int pageShowNum) {
		this.pageShowNum = pageShowNum;
	}

	/**
	 * 获得当前页的页号,序号从1开始,默认为1.
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * 设置当前页的页号,序号从1开始,低于1时自动调整为1.
	 */
	public void setPageNo(final int pageNo) {
		this.pageNo = pageNo;

		if (pageNo < 1) {
			this.pageNo = 1;
		}
	}

	public Page pageNo(final int thePageNo) {
		setPageNo(thePageNo);
		return this;
	}

	/**
	 * 获得每页的记录数量,默认为1.
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * 设置每页的记录数量,低于1时自动调整为1.
	 */
	public void setPageSize(final int pageSize) {
		this.pageSize = pageSize;

		if (pageSize < 1) {
			this.pageSize = 1;
		}
	}

	public Page pageSize(final int thePageSize) {
		setPageSize(thePageSize);
		return this;
	}

	/**
	 * 根据pageNo和pageSize计算当前页第一条记录在总结果集中的位置,序号从1开始.
	 */
	public int getFirst() {
		return ((pageNo - 1) * pageSize) + 1;
	}

	/**
	 * 取得页内的记录列表.
	 */
	public List<T> getResult() {
		return result;
	}

	/**
	 * 设置页内的记录列表.
	 */
	public void setResult(final List<T> result) {
		this.result = result;
	}

	/**
	 * 取得总记录数, 默认值为-1.
	 */
	public long getTotalCount() {
		return totalCount;
	}

	/**
	 * 设置总记录数.
	 */
	public void setTotalCount(final long totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * 根据pageSize与totalCount计算总页数, 默认值为-1.
	 */
	public long getTotalPages() {
		if (totalCount < 0) {
			return -1;
		}

		long count = totalCount / pageSize;
		if (totalCount % pageSize > 0) {
			count++;
		}
		return count;
	}

	/**
	 * 是否还有下一页.
	 */
	public boolean isHasNext() {
		return (pageNo + 1 <= getTotalPages());
	}

	/**
	 * 取得下页的页号, 序号从1开始. 当前页为尾页时仍返回尾页序号.
	 */
	public int getNextPage() {
		if (isHasNext()) {
			return pageNo + 1;
		} else {
			return pageNo;
		}
	}

	/**
	 * 是否还有上一页.
	 */
	public boolean isHasPre() {
		return (pageNo - 1 >= 1);
	}

	/**
	 * 取得上页的页号, 序号从1开始. 当前页为首页时返回首页序号.
	 */
	public int getPrePage() {
		if (isHasPre()) {
			return pageNo - 1;
		} else {
			return pageNo;
		}
	}

}
