package cn.com.whye.core.query;

/**
 * 排序类型（正逆序）枚举类
 * @author 	wq
 * @date	2014-09-16
 */
public enum OrderType {

	ASC("asc"),
	DESC("desc");
	
	private String message;
	
	private OrderType(String message) {
		this.message = message;
	}
	
	public String toString() {
		return this.message;
	}
	
}
