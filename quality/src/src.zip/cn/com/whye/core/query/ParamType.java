package cn.com.whye.core.query;

/**
 * 检索条件的属性值类型枚举类
 * @author 	wq
 * @date	2014-09-16
 */
public enum ParamType {

	S,// String
	I,// Integer
	F,// Float
	N,// Double
	D,// Date  yyyy-MM-dd
	DT,// Date yyyy-MM-dd HH:mm:ss
	DT2;// Date yyyy-MM-dd HH:mm:ss.SSS
	
}
