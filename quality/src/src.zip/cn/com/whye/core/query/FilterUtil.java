package cn.com.whye.core.query;

import org.nutz.lang.Strings;

import cn.com.whye.core.utils.ParseUtil;
import cn.com.whye.core.utils.RegexUtil;

/**
 * 请求域检索条件解析帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class FilterUtil {

	/**
	 * 功能：解析请求域中指定格式的参数并返回，供持久层作进一步处理
	 * 说明：页面传递过来的以ft_字符串开头的参数，指定格式的请求域参数进行解析
	 * 注意：该方法适用于面向对象查询情况
	 * @param filterParamStr 格式如：ft_LIKEA_S_实体属性名
	 * @param filterParamValue	属性值
	 * @return	args[0]=检索类型（FilterType）, args[1]=实体属性名, args[2]=转换成对应数据类型后的属性值
	 */
	public static Object[] getFilterParamValue(String filterParamStr, String filterParamValue) {
		if(Strings.isBlank(filterParamStr)) {
			return null;
		}
		
		if(!RegexUtil.isFilterParam(filterParamStr)) {
			return null;
		}
		
		String[] filterParams = Strings.splitIgnoreBlank(filterParamStr, "_");
		String filterType = filterParams[1];// ft_LIKEA_S_实体属性名 -> LIKEA
		String paramType = filterParams[2];// ft_LIKEA_S_实体属性名 -> S
		
		FilterType ft = FilterType.valueOf(filterType);
		ParamType pt = ParamType.valueOf(paramType);
		
		Object paramValue = null;
		switch (pt) {
			case S:
				paramValue = Strings.sBlank(filterParamValue);
				break;
			case I:
				paramValue = ParseUtil.toInt(filterParamValue);
				break;
			case F:
				paramValue = ParseUtil.toFloat(filterParamValue);
				break;
			case N:
				paramValue = ParseUtil.toDouble(filterParamValue);
				break;
			case D:
				paramValue = ParseUtil.toDate(filterParamValue);
				break;
			case DT:
				paramValue = ParseUtil.toDateTime(filterParamValue);
				break;
			case DT2:
				paramValue = ParseUtil.toDateTime2(filterParamValue);
				break;
			default:
				break;
		}
		
		return new Object[]{ft, filterParams[3], paramValue};
	}
	
}