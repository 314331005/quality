package cn.com.whye.core.utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DWZ消息格式输出帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class DwzUtil {
	
	public static final String PAGE_TAB_ID_PREFIX = "page_";
	
	/**
	 * 重新载入当前页面
	 * @param message
	 * @param navTabId
	 * @return
	 */
	public static Map<String, String> reloadCurrPage(String message, String navTabId) {
		return reloadCurrPage(message, navTabId, "");
	}

	/**
	 * 重新载入当前页面
	 * @param message
	 * @param navTabId
	 * @param extra
	 * @return
	 */
	public static Map<String, String> reloadCurrPage(String message, String navTabId, String extra) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "200");
		jsonMap.put("message", message);
		jsonMap.put("navTabId", PAGE_TAB_ID_PREFIX + navTabId);
		jsonMap.put("rel", navTabId);
		jsonMap.put("extra", extra);
		return jsonMap;
	}

	/**
	 * 默认关闭当前页面，加载navTabId对应的窗体
	 * @param message
	 * @param navTabId
	 * @return
	 */
	public static Map<String, String> reloadTabAndCloseCurrent(String message, String navTabId) {
		return reloadTabAndCloseCurrent(message, navTabId, "");
	}

	/**
	 * 默认关闭当前页面，加载navTabId对应的窗体
	 * @param message
	 * @param navTabId
	 * @param extra
	 * @return
	 */
	public static Map<String, String> reloadTabAndCloseCurrent(String message, String navTabId, String extra) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "200");
		jsonMap.put("message", message);
		jsonMap.put("navTabId", PAGE_TAB_ID_PREFIX + navTabId);
		jsonMap.put("callbackType", "closeCurrent");
		jsonMap.put("extra", extra);
		return jsonMap;
	}

	/**
	 * 后台成功处理，但什么都不做，只返回成功代码等信息
	 * @param message
	 * @param rel
	 * @return
	 */
	public static Map<String, String> nothing(String message, String rel) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "200");
		jsonMap.put("message", message);
		jsonMap.put("rel", rel);
		return jsonMap;
	}
	
	/**
	 * 后台错误处理，返回代码和错误信息
	 * @param message
	 * @param rel
	 * @return
	 */
	public static Map<String, String> error(String message, String rel) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "300");
		jsonMap.put("message", message);
		jsonMap.put("rel", rel);
		return jsonMap;
	}

	/**
	 * 后台出错
	 * @param message
	 * @return
	 */
	public static Map<String, String> stopPageError(String message) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "300");
		jsonMap.put("message", message);
		return jsonMap;
	}
	
	/**
	 * 后台出错
	 * @param message
	 * @param navTabId
	 * @return
	 */
	public static Map<String, String> stopPageAndCloseCurrent(String message, String navTabId) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "300");
		jsonMap.put("message", message);
		jsonMap.put("navTabId", PAGE_TAB_ID_PREFIX + navTabId);
		jsonMap.put("callbackType", "closeCurrent");
		return jsonMap;
	}
	
	/**
	 * 后台错误处理，返回代码和错误信息
	 * @param message
	 * @return
	 */
	public static Map<String, String> sessionTimeout(String message) {
		Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		jsonMap.put("statusCode", "301");
		jsonMap.put("message", message);
		return jsonMap;
	}
	
}
