package cn.com.whye.core.utils;
import org.nutz.lang.Mirror;

import cn.com.whye.core.annotation.ActionDesc;


public class MsgUtil {

	private static final String ONE_AT_LEAST = "请至少勾选一条记录!";
	private static final String NOT_FOUND = "未找到对应的%s!";
	private static final String EXISTS = "%s已存在!";
	private static final String UPDATE_SUCCESS = "%s保存成功";
	private static final String UPDATE_FAILURE = "%s保存失败: %s";
	private static final String DEL_SUCCESS = "%s删除成功";
	private static final String DEL_FAILURE = "%s删除失败: %s";
	private static final String DEL_BATCH_SUCCESS = "%s批量删除操作，成功处理%s/%s条!";
	private static final String DEL_BATCH_FAILURE = "%s批量删除失败，成功处理%s/%s条! %s";
	private static final String SHOW_FAILURE = "%s查看失败: %s";

	private static final String PASSWD_SUCCESS = "密码修改成功";
	private static final String PASSWD_FAILURE = "密码修改失败: %s";
	
	private static <T> String format(final String message, T target, String... exception) {
		Mirror<T> mirror = Mirror.me(target);
		ActionDesc desc = mirror.getAnnotation(ActionDesc.class);
		final String body = desc.value();
		if(exception != null && exception.length > 0) {
			return String.format(message, body, exception);
		} else {
			return String.format(message, body);
		}
	}
	
	private static String format(final String message, String... body) {
		return String.format(message, body);
	}
	
	public static String oneAtLeast() {
		return ONE_AT_LEAST;
	}
	
/*	public static String notFound(String body) {
		return format(NOT_FOUND, body);
	}*/
	
	public static <T> String notFound(T target) {
		return format(NOT_FOUND, target);
	}
	
	public static <T> String exists(T target) {
		return format(EXISTS, target);
	}
	
	public static <T> String updateS(T target) {
		return format(UPDATE_SUCCESS, target);
	}
	
/*	public static <T> String updateF(String body, String exception) {
		return format(UPDATE_FAILURE, body, exception);
	}*/
	
	public static <T> String updateF(T target, String exception) {
		return format(UPDATE_FAILURE, target, exception);
	}
	
/*	public static <T> String delS(String body) {
		return format(DEL_SUCCESS, body);
	}*/
	
	public static <T> String delS(T target) {
		return format(DEL_SUCCESS, target);
	}
	
/*	public static <T> String delF(String body, String exception) {
		return format(DEL_FAILURE, body, exception);
	}*/
	
	public static <T> String delF(T target, String exception) {
		return format(DEL_FAILURE, target, exception);
	}
	
	public static <T> String batchDelS(T target, int sLen, int tLen) {
		return format(DEL_BATCH_SUCCESS, target, String.valueOf(sLen), String.valueOf(tLen));
	}
	
	public static <T> String batchDelF(T target, int sLen, int tLen, String exception) {
		return format(DEL_BATCH_FAILURE, target, String.valueOf(sLen), String.valueOf(tLen), exception);
	}
	
	public static <T> String showF(T target, String exception) {
		return format(SHOW_FAILURE, target, exception);
	}
	
	public static <T> String passwdS(T target) {
		return format(PASSWD_SUCCESS, target);
	}
	
	public static <T> String passwdS(T target, String exception) {
		return format(PASSWD_FAILURE, target, exception);
	}
	
}