package cn.com.whye.core.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;

public class HttpsUtil {

	private static final Log log = Logs.get();

	public static String send(String url, String method, int timeout,
			String keystorePath, String keystorePass) {
		BufferedReader br = null;
		InputStreamReader isr = null;
		InputStream ins = null;
		
		StringBuffer result = new StringBuffer();
		try {
			if(Strings.isBlank(url) || !url.startsWith("https")) {
				throw new Exception("URL validation failed.");
			}
			
			SSLContext sc = SSLContext.getInstance("SSL", "SunJSSE");
			TrustManager[] tms = getTms(keystorePath, keystorePass);
			sc.init(null, tms, new SecureRandom());
			SSLSocketFactory factory = sc.getSocketFactory();
			
			HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier(){
				@Override
				public boolean verify(String hostName, SSLSession session) {
					return hostName.equals(session.getPeerHost());
				}
			});
			HttpsURLConnection conn = (HttpsURLConnection)(new URL(url)).openConnection();
			conn.setSSLSocketFactory(factory);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod(method != null ? method.toUpperCase() : "POST");
			conn.setConnectTimeout(Math.max(timeout, 3000));
	
			ins = conn.getInputStream();
			isr = new InputStreamReader(ins);
			br = new BufferedReader(isr);
			
			String line = null;
			while((line = br.readLine()) != null) {
				result.append(line).append("\n");
			}
		} catch(Exception e) {
			if(log.isErrorEnabled()) {
				log.errorf("https send error : %s", e.getMessage());
			}
		} finally {
			try {
				if(br != null) {
					br.close();
					br = null;
				}
				if(isr != null) {
					isr.close();
					isr = null;
				}
				if(ins != null) {
					ins.close();
					ins = null;
				}
			} catch (IOException e) {
			}
		}
		
		return result.toString();
	}
	
	private static TrustManager[] getTms(String dir, String passwd) throws Exception {
		String tag = TrustManagerFactory.getDefaultAlgorithm();
		TrustManagerFactory factory = TrustManagerFactory.getInstance(tag);
		FileInputStream fis = new FileInputStream(dir);
		KeyStore ks = KeyStore.getInstance("jks");
		ks.load(fis, passwd.toCharArray());
		fis.close();
		factory.init(ks);
		return factory.getTrustManagers();
	}
	
}
