package cn.com.whye.core.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Map;

import org.nutz.lang.Strings;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

public class FtlUtil {  
	
    public static void genHtml(String ftlFilePath, String htmlFilePath, Map<String, Object> data) 
    		throws IOException, TemplateException {
    	if(Strings.isBlank(ftlFilePath)) {
    		throw new IOException(String.format("Template file is invalid. [path=%s]", ftlFilePath));
    	}
    	File ftlFile = new File(ftlFilePath);
    	if(!(ftlFile.exists() && ftlFile.isFile())) {
    		throw new IOException(String.format("Template file is invalid. [path=%s]", ftlFilePath));
    	}
    	
    	File ftlFileDir = ftlFile.getParentFile();
    	final String ftlFileName =  ftlFile.getName();
    	
    	//创建模版对象 
        Configuration cfg = new Configuration();//配制  
        cfg.setDirectoryForTemplateLoading(ftlFileDir); 
        Template template = cfg.getTemplate(ftlFileName, "UTF-8");
        
        OutputStream os = null; 
        Writer sw = null;
        try {
	        os = new FileOutputStream(htmlFilePath);
	        sw = new OutputStreamWriter(os, "UTF-8");
	        template.process(data, sw); //在模版上执行变量赋值操作，并输出到指定的输出流中 
        } catch (Exception e) {
			throw new IOException(String.format("Html file generate failed. [Err=%s]", e.getMessage()));
		} finally {
			if(sw != null) {
				sw.close();
				sw = null;
			}
			if(os != null) {
				os.close();
				os = null;
			}
		}
    }  
}