package cn.com.whye.core.utils;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

import org.nutz.lang.Strings;

public class PinyinUtil {
	
	private static final HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
	
	// 汉语拼音格式输出类
	static {
		// 输出设置，大小写，音标方式等
		format.setCaseType(HanyuPinyinCaseType.LOWERCASE); // 小写
		format.setToneType(HanyuPinyinToneType.WITHOUT_TONE); // 无音调
		format.setVCharType(HanyuPinyinVCharType.WITH_V);
	} 
	
	public static String getPinyin(String src) {
		return getPinyin(src, false);
	}
	
	public static String getPinyin(String src, boolean isFullSpell) {
		if(Strings.isBlank(src)) return "";

		char[] words;
		words = src.toCharArray();
		
		StringBuffer sb = new StringBuffer();
		for(char c : words) {
			if(RegexUtil.isChinese(String.valueOf(c))) { // 中文字符
				try{
					if(isFullSpell) {
						sb.append(PinyinHelper.toHanyuPinyinStringArray(c, format)[0]);
					} else {
						sb.append(PinyinHelper.toHanyuPinyinStringArray(c, format)[0].charAt(0));
					}
				} catch(BadHanyuPinyinOutputFormatCombination e) {
				}
			} else if(((int)c >= 48 || (int)c <= 57) 
					|| ((int)c >= 65 && (int)c <= 90) 
					|| ((int)c >= 97 && (int)c <= 122)){ // 数字或英文字母
				sb.append(c);
			}
		}
		
		return sb.toString();
	}
	
}