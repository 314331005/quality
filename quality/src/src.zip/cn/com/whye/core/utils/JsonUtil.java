package cn.com.whye.core.utils;

import java.util.Collection;
import java.util.Map;

import org.nutz.json.Json;
import org.nutz.json.JsonFormat;
import org.nutz.lang.Strings;


/**
 * JSON转换通用帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class JsonUtil {

	//是否将json格式化后输出
	private static final JsonFormat format = 
		PropsUtil.getBoolean("json.format") ? JsonFormat.nice() : JsonFormat.compact();
	
	public static <T> String toJson(T domain) {
		if (domain == null)
			return null;
		return Json.toJson(domain, format);
	}

	public static <T> String toJson(Collection<T> list) {
		if (list == null || list.isEmpty())
			return null;
		return Json.toJson(list, format);
	}
	
	public static String toJson(Map<?, ?> values) {
		if (values == null || values.isEmpty())
			return null;
		return Json.toJson(values, format);
	}

	public static <T> T fromJson(Class<T> clazz, String jsonString) {
		if (Strings.isBlank(jsonString))
			return null;
		return Json.fromJson(clazz, jsonString);
	}

	public static <T> Collection<T> json2List(Class<T> clazz, String jsonString) {
		if (Strings.isBlank(jsonString))
			return null;
		return Json.fromJsonAsList(clazz, jsonString);
	}

	public static Map<String, Object> json2Map(String jsonString) {
		if (Strings.isBlank(jsonString))
			return null;
		return Json.fromJsonAsMap(Object.class, jsonString);
	}

	public static <T> Map<String, T> json2Map(Class<T> clazz, String jsonString) {
		if (Strings.isBlank(jsonString))
			return null;
		return Json.fromJsonAsMap(clazz, jsonString);
	}

}
