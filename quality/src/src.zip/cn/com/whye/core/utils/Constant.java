package cn.com.whye.core.utils;

public class Constant {
	
	public static final String SYS_USER = "_SYS_USER_";
	
	public static final String SYS_USER_MENU = "_SYS_USER_MENUS_";
	
	public static final String SC_DICTIONARY_NAME = "dics";
	
	public static final String SC_CODE_NAME = "codes";
	
	public static final String SC_ENUM_NAME = "enums";
	
	public static final String SC_TAG_NAME = "tags";
	
	public static final String SC_CODE_TYPE_DEPT = "sys_dept";

	public static final String SC_CODE_PCA_ALL = "PCA_ALL";
	
	public static final String SC_CODE_PCA_P = "PCA_P";
	
	public static final String SC_CODE_PCA_P60 = "000000";
	
	public static final String SC_CODE_PCA_PC = "PCA_PC";
	
	public static final String SC_CODE_PCA_CA = "PCA_CA";
}
