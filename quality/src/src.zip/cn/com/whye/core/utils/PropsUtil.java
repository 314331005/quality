package cn.com.whye.core.utils;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.nutz.lang.Files;
import org.nutz.lang.Lang;

/**
 * 资源文件内容读取帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class PropsUtil {

	//静态资源文件，内容更改后需重启应用服务才生效
	private static final ResourceBundle resource = ResourceBundle.getBundle("static");
	//动态资源文件，内容更改后即使生效
	private static final String ACTIVE_PATH = Files.findFile("active.properties").getPath();
	
	public static final int getInteger(String key) {
		return getInteger(key, -1);
	}
	
	public static final int getInteger(String key, int defaultValue) {
		return ParseUtil.toInt(getString(key), defaultValue);
	}
	
	public static final boolean getBoolean(String key) {
		return "true".equalsIgnoreCase(getString(key));
	}
	
	public static final String getString(String key) {
		return resource.containsKey(key) ? resource.getString(key) : "";
	}
	
	public static final int getActiveInteger(String key) {
		try {
			String value = getActiveString(key);
			return Integer.valueOf(value);
		} catch (Exception e) {
			return -1;
		}
	}
	
	public static final boolean getActiveBoolean(String key) {
		return "true".equalsIgnoreCase(getActiveString(key));
	}
	
	public static final String getActiveString(String key) {
		try {
			Properties props = new Properties();
			props.load(new FileInputStream(ACTIVE_PATH));
			return props.containsKey(key) ? props.getProperty(key, "") : "";
		} catch(Exception e) {
			return "";
		}
	}
	
	public static final Map<String, String> getActiveValues(String... keys) {
		return getActiveValues(Arrays.asList(Lang.isEmptyArray(keys) ? new String[]{} : keys));
	}
	
	public static final Map<String, String> getActiveValues(Collection<String> keys) {
		Map<String, String> values = new HashMap<String, String>();
		try {
			if(Lang.isEmpty(keys)) return values;
			
			Properties props = new Properties();
			props.load(new FileInputStream(ACTIVE_PATH));
			for(String key : keys) {
				values.put(key, (props.containsKey(key) ? props.getProperty(key, "") : ""));
			}
		} catch(Exception e) {
		}
		return values;
	}
}
