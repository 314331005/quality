package cn.com.whye.core.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HtmlUtil {
	
	public static String escape(String value) {
		//.replaceAll("&","&amp;")
		return value.replaceAll("<", "&lt;")
				    .replaceAll(">", "&gt;")
				    .replaceAll("'", "&prime;")
				    .replaceAll("\"", "&quot;");
	}
	
	public static String unescape(String value) {
		//.replaceAll("&amp;","&")
		return value.replaceAll("&lt;", "<") 
				    .replaceAll("&gt;", ">")
				    .replaceAll("&prime;", "'")
				    .replaceAll("&quot;", "\"");
	}
	
	public static String filter(String value) {
		// 过滤所有以<开头以0个或1个>结尾的标签
		String regex = "<([^>]*)>?"; 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(value);
		StringBuffer sb = new StringBuffer();
		boolean result = matcher.find();
		while (result) {
			matcher.appendReplacement(sb, "");
			result = matcher.find();
		}
		matcher.appendTail(sb);
		return sb.toString();
	}

}
