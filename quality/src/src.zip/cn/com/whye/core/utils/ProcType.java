package cn.com.whye.core.utils;

public enum ProcType {

	Bit(java.sql.Types.BIT),
	Int(java.sql.Types.INTEGER),
	Long(java.sql.Types.BIGINT),
	Float(java.sql.Types.FLOAT),
	Double(java.sql.Types.DOUBLE),
	String(java.sql.Types.VARCHAR),
	Date(java.sql.Types.DATE),
	DateTime(java.sql.Types.TIMESTAMP),
	Boolean(java.sql.Types.BOOLEAN);
	
	private int type;
	
	private ProcType(int type) {
		this.type = type;
	}
	
	public int value() {
		return this.type;
	}
	
}
