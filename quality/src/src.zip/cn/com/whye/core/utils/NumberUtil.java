package cn.com.whye.core.utils;

import java.math.BigDecimal;

public class NumberUtil {
	
	public static double add(double a, double b) {
		BigDecimal n1 = BigDecimal.valueOf(a);
		BigDecimal n2 = BigDecimal.valueOf(b);
		return n1.add(n2).doubleValue();
	}

	public static double sub(double a, double b) {
		BigDecimal n1 = BigDecimal.valueOf(a);
		BigDecimal n2 = BigDecimal.valueOf(b);
		return n1.subtract(n2).doubleValue();
	}
	
}
