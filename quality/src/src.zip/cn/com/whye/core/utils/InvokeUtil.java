package cn.com.whye.core.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

import org.nutz.lang.Mirror;
import org.nutz.lang.Strings;

import cn.com.whye.core.annotation.TreeDefine;

@SuppressWarnings("unchecked")
public class InvokeUtil {
	
	public static void setValue(Object obj, String propName, Object propValue) {
		Mirror mirror = Mirror.me(obj);
		if(containsProperty(mirror, obj, propName)) {
			mirror.setValue(obj, propName, propValue);
		}
	}
	
	public static Object getValue(Object obj, String propName) {
		Mirror mirror = Mirror.me(obj);
		return containsProperty(mirror, obj, propName) ? mirror.getValue(obj, propName) : null;
	}
	
	public static <T> T newInstance(Class<T> clazz) {
		Mirror<T> mirror = Mirror.me(clazz);
		return mirror.born();
	}
	
	public static <T> T newInstance(Class<T> clazz, Object... args) {
		Mirror<T> mirror = Mirror.me(clazz);
		return mirror.born(args);
	}
	
	public static Class<?> getClass(String className) {
		try {
			Class<?> clazz = Class.forName(className);
			return clazz;
		} catch (ClassNotFoundException e) {
		}
		return null;
	}
	
	public static void method(Object obj, String methodName, Object args) {
		Mirror mirror = Mirror.me(obj);
		mirror.invoke(obj, methodName, args);
	}
	
	public static Class getPropertyType(Object obj, String propName) {
		try {
			Mirror mirror = Mirror.me(obj);
			Field f = mirror.getField(propName);
			return f != null ? f.getType() : null;
		} catch (NoSuchFieldException e) {
			return null;
		}
	}
	
	public static boolean isPropertyInstanceOfType(Object obj, String propName, Class clazz) {
		Class origClazz = getPropertyType(obj, propName);
		return origClazz != null && (origClazz == clazz);
	}
	
	public static boolean containsProperty(Object obj, String propName) {
		try {
			Mirror mirror = Mirror.me(obj);
			Field f = mirror.getField(propName);
			return f != null && !Strings.isBlank(f.getName());
		} catch (NoSuchFieldException e) {
			return false;
		}
	}
	
	public static boolean containsProperty(Mirror mirror, Object obj, String propName) {
		try {
			if(mirror == null) {
				return false;
			}
			Field f = mirror.getField(propName);
			return f != null && !Strings.isBlank(f.getName());
		} catch (NoSuchFieldException e) {
			return false;
		}
	}
	
	public static void copyProperties(Object orig, Object target) {
		Mirror mOrig = Mirror.me(orig);
		Mirror mTarget = Mirror.me(target);
		
		String fieldName = null;
		Object fieldValue = null;
		Field[] fields = mOrig.getFields();
		for(Field f : fields) {
			fieldName = f.getName();
			if(containsProperty(mTarget, target, fieldName)) {
				fieldValue = mOrig.getValue(orig, fieldName);
				setValue(target, fieldName, fieldValue);
			}
		}
	}
	
	public static <T> TreeDefine getTreeNodeDefine(Class<T> clazz) {
		Mirror<T> mirror = Mirror.me(clazz);
		TreeDefine def = mirror.getAnnotation(TreeDefine.class);
		return def;
	}
	
	public static <T> String getTreeNodeText(Class<T> clazz) {
		Mirror<T> mirror = Mirror.me(clazz);
		TreeDefine def = mirror.getAnnotation(TreeDefine.class);
		return def.text();
	}
	
	public static <T> String isTreeNodeValid(Class<T> clazz) {
		Mirror<T> mirror = Mirror.me(clazz);
		TreeDefine def = mirror.getAnnotation(TreeDefine.class);
		return def.valid();
	}
	
	public static <V, T extends Annotation> T getAnnotation(Class<V> entryClass, Class<T> annoClass, String propName) {
		try {
			Mirror<V> mirror = Mirror.me(entryClass);
			return mirror.getField(propName).getAnnotation(annoClass);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static <V, T extends Annotation> T getAnnotation(Class<V> entryClass, Class<T> annoClass) {
		Mirror<V> mirror = Mirror.me(entryClass);
		return mirror.getAnnotation(annoClass);
	}
	
	/*
	public static <T> void setValue(Class<T> clazz, String propName, Object propValue) {
		Mirror<T> mirror = Mirror.me(clazz);
		mirror.setValue(clazz, propName, propValue);
	}
	
	public static Object getValue(Class<T> clazz, String propName) {
		Mirror mirror = Mirror.me(obj);
		return mirror.getValue(obj, propName);
	}
	*/

}
