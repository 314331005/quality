package cn.com.whye.core.utils;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.nutz.lang.Strings;

/**
 * 数据类型转换帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class ParseUtil {
	
	private static final NumberFormat numberFmt = new DecimalFormat("#0.00");
	private static final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd");
	private static final SimpleDateFormat datetimeFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final SimpleDateFormat datetimeFmt2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	public static String toString(Object value) {
		return toString(value, null);
	}
	
	public static String toString(Object value, String defaultValue) {
		if(value == null) return defaultValue;
		return String.valueOf(value);
	}
	
	public static int toInt(Object value) {
		return toInt(value, -1);
	}
	
	public static int toInt(Object value, int defaultValue) {
		try {
			if (value == null) {
				return defaultValue;
			}
			String str = String.valueOf(value);
			if (!Strings.isBlank(str)) {
				return Integer.valueOf(str.trim());
			}
		} catch (Exception e) {
		}
		return defaultValue;
	}
	
	public static long toLong(Object value) {
		return toLong(value, -1L);
	}

	public static long toLong(Object value, long defaultValue) {
		try {
			if (value == null) {
				return defaultValue;
			}
			String str = String.valueOf(value);
			if (!Strings.isBlank(str)) {
				return Long.valueOf(str.trim());
			}
		} catch (Exception e) {
		}
		return defaultValue;
	}
	
	public static float toFloat(Object value) {
		return toFloat(value, 0.0F);
	}

	public static float toFloat(Object value, float defaultValue) {
		try {
			if (value == null) {
				return defaultValue;
			}
			String str = String.valueOf(value);
			if (!Strings.isBlank(str)) {
				return Float.valueOf(str.trim());
			}
		} catch (Exception e) {
		}
		return defaultValue;
	}
	
	public static double toDouble(String value) {
		return toDouble(value, 0.00D);
	}
	
	public static double toDouble(String value, double defaultValue) {
		try {
			return numberFmt.parse(value).doubleValue();
		} catch(Exception e) {
			return defaultValue;
		}
	}

	public static boolean toBoolean(Object value) {
		try {
			if (value == null) {
				return false;
			}
			String str = String.valueOf(value);
			if (!Strings.isBlank(str)) {
				return Boolean.valueOf(str);
			}
		} catch (Exception e) {
		}
		return false;
	}
	
	public static Date toDate(String value) {
		try {
			return dateFmt.parse(value);
		} catch(Exception e) {
			return new Date();
		}
	}
	
	public static Date toDateTime(String value) {
		try {
			return datetimeFmt.parse(value);
		} catch(Exception e) {
			return new Date();
		}
	}
	
	public static Date toDateTime2(String value) {
		try {
			return datetimeFmt2.parse(value);
		} catch(Exception e) {
			return new Date();
		}
	}
	
	public static Timestamp toTimestamp(Object value) {
		if(value == null) return null;
		return toTimestamp(String.valueOf(value));
	}
	
	public static Timestamp toTimestamp(String value) {
		try {
			return Timestamp.valueOf(value);
		} catch(Exception e) {
			return new Timestamp(System.currentTimeMillis());
		}
	}
	
	public static String[] toArray(String value, String splitStr) {
		return Strings.splitIgnoreBlank(value, splitStr);
	}
	
}
