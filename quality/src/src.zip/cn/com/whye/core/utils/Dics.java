package cn.com.whye.core.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.nutz.json.Json;
import org.nutz.lang.Lang;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.resource.NutResource;
import org.nutz.resource.Scans;

public final class Dics {

	private static final Log log = Logs.getLog(Dics.class);
	
	private static final Map<String, Map<String, Object>> dicMap = new HashMap<String, Map<String, Object>>();
	
	/**
	 * 系统初始化时从/dic目录下加载.js或.json文件内容作为系统固定编码数据
	 * @param sc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Map<String, Object>> loadDirectory(ServletContext sc) {
		try {
			List<NutResource> list = Scans.me().loadResource("^(.+[.])(js|json)$", "dic/");
			if(Lang.isEmpty(list)) {
				return dicMap;
			}
			
			for(NutResource nr : list) {
				try {
					String s = Lang.readAll(nr.getReader());
					if(Strings.isBlank(s)) {
						continue;
					}
			        Map<String, Map<String, Object>> map = (Map<String, Map<String, Object>>) Json.fromJson(s);
			        dicMap.putAll(map);
			        
			        if(log.isInfoEnabled()) {
						log.infof("### File '%s' has been loaded", nr.getName());
					}
				} catch(IOException e) {
					if(log.isErrorEnabled()) {
						log.errorf("### File '%s' loading failed", nr.getName());
					}
					continue;
				}
			}
		} catch(Exception e) {
			if(log.isDebugEnabled()) {
				log.debug("### System not found '*.js' file in 'dic' folder.");
			}
		}
		
		sc.setAttribute(Constant.SC_DICTIONARY_NAME, dicMap);
		
		return dicMap;
	}
	
	public static final String get(String type, String code) {
		if(Strings.isBlank(type) || Strings.isBlank(code)) {
			return "".intern();
		}
		
		Map<String, Object> values = dicMap.containsKey(type) ? dicMap.get(type) : null;
		return !Lang.isEmpty(values) ? Strings.sBlank(values.get(code), "") : "".intern();
	}
	
}
