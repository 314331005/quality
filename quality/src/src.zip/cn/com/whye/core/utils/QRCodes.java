package cn.com.whye.core.utils;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.imageio.ImageIO;

import org.nutz.lang.Files;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class QRCodes {
	
	private static final Log log = Logs.get();

	public static void encode(String content, String destPath, String logoPath) {
		encode(content, 200, 200, destPath, logoPath);
	}

	/**
	 * 生成二维码
	 * @param content	二维码图片的内容
	 * @param width		二维码图片的宽度
	 * @param height	二维码图片的高度
	 * @param destPath	二维码图片的生成位置
	 */
	public static void encode(String content, int width, int height,
			String destPath, String logoPath) {
		try {
			Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
			hints.put(EncodeHintType.MARGIN, 1);
			// 指定纠错等级
			hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
			// 指定编码格式
			hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

			Writer writer = new QRCodeWriter();
			BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints);
			// 附加logo图标至二维码图片中
			logo4Image(matrix, destPath, logoPath);
		} catch (WriterException e) {
			if(log.isErrorEnabled()) {
				log.errorf("二维码图片生成失败：%s", e.getMessage());
			}
		} catch (IOException e) {
			if(log.isErrorEnabled()) {
				log.errorf("二维码图片生成失败：%s", e.getMessage());
			}
		}
	}

	/**
	 * 二维码内容解析
	 * @param destPath	二维码图片的生成位置
	 */
	public static String decode(String destPath) {
		try {
			if(Strings.isBlank(destPath)) {
				throw new Exception("图片路径为空");
			}
			
			BufferedImage image = ImageIO.read(new File(destPath));
			if (image == null) {
				throw new Exception("图片路径不存在");
			}
			
			LuminanceSource source = new BufferedImageLuminanceSource(image);
			BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

			Hashtable<DecodeHintType, Object> hints = new Hashtable<DecodeHintType, Object>();
			hints.put(DecodeHintType.CHARACTER_SET, "UTF-8"); // 此处需要设置解码编码，否则乱码

			Reader reader = new QRCodeReader();
			Result result = reader.decode(bitmap, hints);
			return result.getText();
		} catch (Exception e) {
			if(log.isErrorEnabled()) {
				log.errorf("二维码图片解析失败：%s", e.getMessage());
			}
			return null;
		}
	}

	/**
	 * 附加logo图标至二维码图片中
	 * @param matrix
	 * @param destPath
	 * @param logoPath
	 * @throws IOException
	 */
	private static void logo4Image(BitMatrix matrix, String destPath, String logoPath) throws IOException {
		// 修改二维码的颜色和背景色
		BufferedImage image = setColor(matrix);
		
		if(!Strings.isBlank(logoPath)) {
			BufferedImage logo = ImageIO.read(new File(logoPath));
	
			MatrixToLogoImageConfig config = new MatrixToLogoImageConfig();
			Graphics2D g = image.createGraphics();
			// 建议logo图片大小不要超过二维码的1/5
			int width = image.getWidth() / config.getLogoPart();
			int height = image.getHeight() / config.getLogoPart();
			// 设置logo居中显示
			int x = (image.getWidth() - width) / 2;
			int y = (image.getHeight() - height) / 2;
			g.drawImage(logo, x, y, width, height, Color.RED, null);
			/*
			// 给logo画边框 构造一个具有指定线条宽度以及 cap 和 join 风格的默认值的实心 BasicStroke	
			g.setStroke(new BasicStroke(config.getBorder()));
			g.setColor(config.getBorderColor());
			g.drawRect(x, y, width, height);
			*/
			// 释放系统资源
			g.dispose();
		}
		// 将logo图片附加到二维码图片中
		File imageFile = Files.createFileIfNoExists(destPath);
		ImageIO.write(image, "png", imageFile);
	}

	/**
	 * 设置二维码图形的颜色和背景色
	 */
	private static BufferedImage setColor(BitMatrix matrix) {
		final int BLACK = 0xFF000000; // 二维码图形的颜色
		// final int GREEN = 0xFF33DD00; //二维码图形的颜色
		final int WHITE = 0xFFFFFFFF; // 二维码图形的背景色

		int width = matrix.getWidth();
		int height = matrix.getHeight();
		BufferedImage image = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				image.setRGB(x, y, matrix.get(x, y) ? BLACK : WHITE);
			}
		}
		return image;
	}

}

class MatrixToLogoImageConfig {
	// logo默认边框颜色
	public static final Color DEFAULT_BORDERCOLOR = Color.RED;
	// logo默认边框宽度
	public static final int DEFAULT_BORDER = 2;
	// logo大小默认为照片的1/5
	public static final int DEFAULT_LOGOPART = 5;

	private final int border = DEFAULT_BORDER;
	private final Color borderColor;
	private final int logoPart;

	/**
	 * Creates a default config with on color {@link #BLACK} and off color
	 * {@link #WHITE}, generating normal black-on-white barcodes.
	 */
	public MatrixToLogoImageConfig() {
		this(DEFAULT_BORDERCOLOR, DEFAULT_LOGOPART);
	}

	public MatrixToLogoImageConfig(Color borderColor, int logoPart) {
		this.borderColor = borderColor;
		this.logoPart = logoPart;
	}

	public Color getBorderColor() {
		return borderColor;
	}

	public int getBorder() {
		return border;
	}

	public int getLogoPart() {
		return logoPart;
	}
}