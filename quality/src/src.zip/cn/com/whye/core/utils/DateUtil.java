package cn.com.whye.core.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期格式转换帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public class DateUtil {
	
	public static String[] getCurrDateAndTime() {
		String currDate = DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss");
		int index = currDate.indexOf(" ");
		String[] arr = {currDate.substring(0, index), currDate.substring(index+1)};
		return arr;
	}
	
	/**
	 * 获取当前日期时间
	 * 
	 * @return
	 */
	public static Date getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		return cal.getTime();
	}

	/**
	 * 获取当前时间
	 * 
	 * @param format
	 * @return
	 */
	public static String getCurrentDate(String format) {
		if (format == null || format.equals("")) {
			return "";
		}
		SimpleDateFormat sdt = new SimpleDateFormat(format);
		return sdt.format(new Date());
	}

	/**
	 * 字符串转换日期格式
	 * 
	 * @param sDate
	 * @return
	 */
	public static Date formatDate(String sDate) {

		if (sDate == null || sDate.equals(""))
			return null;
		SimpleDateFormat sdt = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = sdt.parse(sDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static long dateDiff(Date startdate, Date enddate) {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(startdate);
		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(enddate);
		long milliseconds1 = calendar1.getTimeInMillis();
		long milliseconds2 = calendar2.getTimeInMillis();
		return (milliseconds2 - milliseconds1) / (24 * 60 * 60 * 1000);
	}

	/**
	 * 字符串转换为日期时间格式
	 * 
	 * @param sDate
	 * @return
	 */
	public static Date formatDate(String sDate, String format) {
		if (sDate == null || sDate.equals(""))
			return null;
		SimpleDateFormat sdt = new SimpleDateFormat(format);
		Date date = null;
		try {
			date = sdt.parse(sDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * 时间转换为字符串格式
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String formatDate(Date date, String format) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat sdt = new SimpleDateFormat(format);
		return sdt.format(date);
	}

	/**
	 * 获取当前月的最后一天
	 * 
	 * @param format
	 * @return
	 */
	public static String getLastDayWithMonth() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE, 1);
		cal.roll(Calendar.DATE, -1);
		SimpleDateFormat sdt = new SimpleDateFormat("yyyy-MM-dd");
		return sdt.format(cal.getTime()) + " 23:59:59";
	}

	public static int getLastDayWithMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 获取当前月的第一天
	 * 
	 * @param format
	 * @return
	 */
	public static String getFirstDayWithMonth() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE, 1);
		SimpleDateFormat sdt = new SimpleDateFormat("yyyy-MM-dd");
		return sdt.format(cal.getTime()) + " 00:00:00";
	}

	/**
	 * 增加天数 正数表示添加，负数表示减去天数
	 * 
	 * @param date
	 * @param iDays
	 * @return
	 */
	public static String addDay(String date, int iDays) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(formatDate(date, "yyyy-MM-dd"));
		cal.add(Calendar.DATE, iDays);
		SimpleDateFormat sdt = new SimpleDateFormat("yyyy-MM-dd");
		return sdt.format(cal.getTime());
	}

	/**
	 * 增加天数 正数表示添加，负数表示减去天数
	 * 
	 * @param date
	 * @param iDays
	 * @return
	 */
	public static Date addDay(Date date, int iDays) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, iDays);
		return cal.getTime();
	}

	public static Date addMonth(Date date, int iMonths) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, iMonths);
		return cal.getTime();
	}

	public static String formatDate(int milliseconds) {
		SimpleDateFormat sdt = new SimpleDateFormat("yyyy-MM-dd");
		return sdt.format(milliseconds);
	}
	
}
