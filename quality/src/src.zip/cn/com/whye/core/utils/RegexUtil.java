package cn.com.whye.core.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.nutz.lang.Strings;

/**
 * 字符串格式的正则判断帮助类
 * @author 	wq
 * @date	2014-09-16
 */
public final class RegexUtil {

	/**
	 * 是否是正确的过滤检索条件格式
	 * @return
	 */
	public static boolean isFilterParam(String filterString) {
		final String regex = ("^(ft|cri)_(EQ|LIKEL|LIKER|LIKEA|LIKEAI|GT|GE|LT|LE|NE|IN|NI)_(S|I|F|N|D|DT|DT2)_[a-zA-Z]{1}[a-zA-Z0-9]*$").intern();
		return isMatch(filterString, regex);
	}
	
	/**
	 * 是否是可识别的日期格式
	 * 格式示例：yyyy/MM/dd  yyyy/MM-dd  yyyy-MM-dd  yyyy-M-dd  yyyy-MM-d yyyy-MM-dd HH:mm:ss.SSS 等
	 * 注：只校验格式是否正确，日期是否正确不做判断（如不存在2月30号）
	 * @param str
	 * @return
	 */
	public static boolean isDate(String str) {
		final String dateRegex = ("^[1-9]{1}[0-9]{3}(\\-|/)([0]?[1-9]{1}|[1]{1}[0-2]{1})(\\-|/)([0]?[1-9]{1}|[1-2]{1}[0-9]{1}|[3]{1}[0-1]{1})").intern();;
		final String regex = (dateRegex + "(\\s{1}([0]?[0-9]{1}|[1]{1}[0-9]{1}|[2]{1}[0-3]{1}):([0]?|[1-5]{1})[0-9]{1}:([0]?|[1-5]{1})[0-9]{1}(\\.[0-9]{3}|)|)$").intern();
		return isMatch(str, regex);
	}
	
	public static boolean isChinese(String str) {
		final String regex = "[\u4E00-\u9FA5]+";
		return isMatch(str, regex);
	}
	
	public static boolean isMatch(String str, String regex) {
		if(Strings.isBlank(str)) {
			return false;
		}
		
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);
		return m.find();
	}
	
}