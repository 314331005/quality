package cn.com.whye.core.http;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.nutz.lang.Lang;
import org.nutz.lang.Strings;

import cn.com.whye.core.utils.HtmlUtil;

/**
 * 自定义request请求特殊字符过滤器
 * @author 	wq
 * @date	2015-05-11
 */
@SuppressWarnings("unchecked")
public class MyHttpServletRequest extends HttpServletRequestWrapper {

	public MyHttpServletRequest(HttpServletRequest request) {
		super(request);
	}

	@Override
	public String getParameter(String name) {
		final String value = super.getParameter(name);
		return Strings.isBlank(value) ? value : HtmlUtil.escape(value);
	}

	@Override
	public Map<String, String[]> getParameterMap() {
		Map<String, String[]> paramsMap = super.getParameterMap();
		
		for(Map.Entry<String, String[]> m : paramsMap.entrySet()) {
			m.setValue(getParameterValues(m.getKey()));
		}
		
		return paramsMap;
	}

	@Override
	public String[] getParameterValues(String name) {
		String[] values = super.getParameterValues(name);
		
		if(!Lang.isEmptyArray(values)) {
			String paramValue = null;
			for (int i=0; i<values.length; i++) {
				paramValue = values[i];
				if(Strings.isBlank(paramValue)) {
					continue;
				}
				
				// 转义需要过滤的特殊字符
				values[i] = HtmlUtil.escape(paramValue);
			}
		}
		return values;
	}

}
