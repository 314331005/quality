package cn.com.whye.export.service;

import java.util.Map;

import cn.com.whye.core.service.IBaseService;
import cn.com.whye.export.domain.ExportModel;
import cn.com.whye.export.domain.ImportModel;

public interface IExportService extends IBaseService {

	public int xlsDataImp(String filePath, Class<?> clazz, ImportModel m) throws Exception;
	
	public String xlsDataExp(String filePath, 
			Class<?> clazz, Map<String, String> fitlerParams, ExportModel m) throws Exception;
	
}
