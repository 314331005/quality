package cn.com.whye.export.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import cn.com.whye.export.format.Formator;

/**
 * 数据导出格式化
 * @author 	wq
 * @date	2014-09-29
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Documented
public @interface ExportFmt {
	
	Class<? extends Formator> formator(); 

	String pattern(); 
	
}
